package com.mycompany.bd;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.sql.SQLException;

public class FormularioVentasDetalle extends JFrame {

    JTextField txtId;
    JTextField txtIdVenta;
    JTextField txtIdProducto;
    JTextField txtCantidad;
    JTextField txtPrecio;
    JTextArea areaResultado;

    VentaDetalleCRUD crud = new VentaDetalleCRUD();

    public FormularioVentasDetalle() {

        setTitle("Gestión de Detalles de Venta");
        setSize(520, 575);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(43, 45, 66));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        panelFondo.setLayout(null);
        setContentPane(panelFondo);

        Font fuenteEtiquetas = new Font("Segoe UI", Font.BOLD, 12);
        Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 12);

        Color colorTextoEtiquetas = Color.WHITE;
        Color colorCamposFondo = new Color(30, 30, 30);
        Color colorCamposTexto = Color.WHITE;
        Color colorBordeCampos = new Color(43, 45, 66);

        // TÍTULO

        JLabel titulo = new JLabel(
                "GESTIÓN DE DETALLES DE VENTA",
                SwingConstants.CENTER
        );

        titulo.setBounds(20, 15, 460, 25);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(colorTextoEtiquetas);
        panelFondo.add(titulo);

        // ID DETALLE

        JLabel lblId = new JLabel("ID Detalle:");
        lblId.setBounds(30, 60, 80, 25);
        lblId.setFont(fuenteEtiquetas);
        lblId.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblId);

        txtId = new JTextField();
        txtId.setBounds(110, 60, 110, 28);
        txtId.setFont(fuenteCampos);
        txtId.setBackground(colorCamposFondo);
        txtId.setForeground(colorCamposTexto);
        txtId.setCaretColor(Color.WHITE);
        txtId.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtId);

        // ID VENTA

        JLabel lblIdVenta = new JLabel("ID Venta:");
        lblIdVenta.setBounds(250, 60, 80, 25);
        lblIdVenta.setFont(fuenteEtiquetas);
        lblIdVenta.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblIdVenta);

        txtIdVenta = new JTextField();
        txtIdVenta.setBounds(330, 60, 140, 28);
        txtIdVenta.setFont(fuenteCampos);
        txtIdVenta.setBackground(colorCamposFondo);
        txtIdVenta.setForeground(colorCamposTexto);
        txtIdVenta.setCaretColor(Color.WHITE);
        txtIdVenta.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtIdVenta);

        // ID PRODUCTO

        JLabel lblIdProducto = new JLabel("ID Producto:");
        lblIdProducto.setBounds(30, 105, 80, 25);
        lblIdProducto.setFont(fuenteEtiquetas);
        lblIdProducto.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblIdProducto);

        txtIdProducto = new JTextField();
        txtIdProducto.setBounds(110, 105, 360, 28);
        txtIdProducto.setFont(fuenteCampos);
        txtIdProducto.setBackground(colorCamposFondo);
        txtIdProducto.setForeground(colorCamposTexto);
        txtIdProducto.setCaretColor(Color.WHITE);
        txtIdProducto.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtIdProducto);

        // CANTIDAD

        JLabel lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setBounds(30, 150, 80, 25);
        lblCantidad.setFont(fuenteEtiquetas);
        lblCantidad.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblCantidad);

        txtCantidad = new JTextField();
        txtCantidad.setBounds(110, 150, 360, 28);
        txtCantidad.setFont(fuenteCampos);
        txtCantidad.setBackground(colorCamposFondo);
        txtCantidad.setForeground(colorCamposTexto);
        txtCantidad.setCaretColor(Color.WHITE);
        txtCantidad.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtCantidad);

        // PRECIO

        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setBounds(30, 195, 80, 25);
        lblPrecio.setFont(fuenteEtiquetas);
        lblPrecio.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblPrecio);

        txtPrecio = new JTextField();
        txtPrecio.setBounds(110, 195, 360, 28);
        txtPrecio.setFont(fuenteCampos);
        txtPrecio.setBackground(colorCamposFondo);
        txtPrecio.setForeground(colorCamposTexto);
        txtPrecio.setCaretColor(Color.WHITE);
        txtPrecio.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtPrecio);

        // BOTONES

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(30, 240, 100, 32);
        btnBuscar.setBackground(new Color(0, 119, 182));
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setFont(fuenteEtiquetas);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnBuscar);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(140, 240, 100, 32);
        btnGuardar.setBackground(new Color(40, 167, 69));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFont(fuenteEtiquetas);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnGuardar);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(250, 240, 110, 32);
        btnActualizar.setBackground(new Color(247, 127, 0));
        btnActualizar.setForeground(Color.WHITE);
        btnActualizar.setFont(fuenteEtiquetas);
        btnActualizar.setFocusPainted(false);
        btnActualizar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnActualizar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(370, 240, 100, 32);
        btnEliminar.setBackground(new Color(214, 40, 40));
        btnEliminar.setForeground(Color.WHITE);
        btnEliminar.setFont(fuenteEtiquetas);
        btnEliminar.setFocusPainted(false);
        btnEliminar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnEliminar);

        // RESULTADOS

        areaResultado = new JTextArea();
        areaResultado.setFont(new Font("Consolas", Font.PLAIN, 12));
        areaResultado.setLineWrap(true);
        areaResultado.setWrapStyleWord(true);
        areaResultado.setBackground(colorCamposFondo);
        areaResultado.setForeground(colorCamposTexto);
        areaResultado.setCaretColor(Color.WHITE);
        areaResultado.setBorder(new EmptyBorder(8, 8, 8, 8));

        JScrollPane scrollPane = new JScrollPane(areaResultado);
        scrollPane.setBounds(30, 295, 440, 210);
        scrollPane.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(scrollPane);

        // GUARDAR

        btnGuardar.addActionListener(e -> ejecutarOperacion(() -> {

            int idVenta = leerEntero(txtIdVenta);
            int idProducto = leerEntero(txtIdProducto);
            int cantidad = leerEntero(txtCantidad);
            double precio = leerDouble(txtPrecio);

            int filas = crud.insertar(
                    idVenta,
                    idProducto,
                    cantidad,
                    precio
            );

            areaResultado.setText(
                    filas > 0
                    ? "Detalle de venta guardado correctamente."
                    : "No se pudo guardar el detalle."
            );
        }));

        // BUSCAR

        btnBuscar.addActionListener(e -> ejecutarOperacion(() -> {

            int id = leerId();

            areaResultado.setText(crud.buscar(id));
        }));

        // ACTUALIZAR

        btnActualizar.addActionListener(e -> ejecutarOperacion(() -> {

            int id = leerId();
            int idVenta = leerEntero(txtIdVenta);
            int idProducto = leerEntero(txtIdProducto);
            int cantidad = leerEntero(txtCantidad);
            double precio = leerDouble(txtPrecio);

            int filas = crud.actualizar(
                    id,
                    idVenta,
                    idProducto,
                    cantidad,
                    precio
            );

            areaResultado.setText(
                    filas > 0
                    ? "Detalle actualizado correctamente."
                    : "No se encontró un detalle con ese ID."
            );
        }));

        // ELIMINAR

        btnEliminar.addActionListener(e -> ejecutarOperacion(() -> {

            int id = leerId();

            int filas = crud.eliminar(id);

            areaResultado.setText(
                    filas > 0
                    ? "Detalle eliminado correctamente."
                    : "No se encontró un detalle con ese ID."
            );
        }));

        setVisible(true);
    }

    private int leerId() {

        int id = Integer.parseInt(txtId.getText().trim());

        if (id <= 0) {
            throw new NumberFormatException();
        }

        return id;
    }

    private int leerEntero(JTextField campo) {

        int valor = Integer.parseInt(campo.getText().trim());

        if (valor <= 0) {
            throw new NumberFormatException();
        }

        return valor;
    }

    private double leerDouble(JTextField campo) {

        double valor = Double.parseDouble(
                campo.getText().trim().replace(",", ".")
        );

        if (valor < 0) {
            throw new NumberFormatException();
        }

        return valor;
    }

    private void ejecutarOperacion(Operacion operacion) {

        try {

            operacion.ejecutar();

        } catch (NumberFormatException e) {

            areaResultado.setText(
                    "Ingrese valores numéricos válidos."
            );

        } catch (SQLException e) {

            areaResultado.setText(
                    "Error al acceder a la base de datos: "
                    + e.getMessage()
            );
        }
    }

    @FunctionalInterface
    private interface Operacion {
        void ejecutar() throws SQLException;
    }
}