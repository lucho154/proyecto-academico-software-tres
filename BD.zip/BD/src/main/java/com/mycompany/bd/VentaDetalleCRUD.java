package com.mycompany.bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VentaDetalleCRUD {

    public int insertar(int idVenta, int idProducto,
                        int cantidad, double precio)
            throws SQLException {

        String sql = "INSERT INTO ventas_detalle "
                   + "(id_venta, id_producto, cantidad, precio) "
                   + "VALUES (?, ?, ?, ?)";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idVenta);
            ps.setInt(2, idProducto);
            ps.setInt(3, cantidad);
            ps.setDouble(4, precio);

            return ps.executeUpdate();
        }
    }

    public String buscar(int id) throws SQLException {

        String sql = "SELECT * FROM ventas_detalle "
                   + "WHERE id_detalle=?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                return "ID Detalle: "
                        + rs.getInt("id_detalle")
                        + "\nID Venta: "
                        + rs.getInt("id_venta")
                        + "\nID Producto: "
                        + rs.getInt("id_producto")
                        + "\nCantidad: "
                        + rs.getInt("cantidad")
                        + "\nPrecio: "
                        + rs.getDouble("precio");
            }

            return "No se encontró un detalle con ese ID.";
        }
    }

    public int actualizar(int id, int idVenta,
                          int idProducto, int cantidad,
                          double precio)
            throws SQLException {

        String sql = "UPDATE ventas_detalle SET "
                   + "id_venta=?, id_producto=?, cantidad=?, precio=? "
                   + "WHERE id_detalle=?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idVenta);
            ps.setInt(2, idProducto);
            ps.setInt(3, cantidad);
            ps.setDouble(4, precio);
            ps.setInt(5, id);

            return ps.executeUpdate();
        }
    }

    public int eliminar(int id) throws SQLException {

        String sql = "DELETE FROM ventas_detalle "
                   + "WHERE id_detalle=?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate();
        }
    }
}