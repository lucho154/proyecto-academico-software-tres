package com.mycompany.bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductoCRUD {

    public int insertar(String nombre, double precio, int stock,
                        int idProveedor) throws SQLException {

        String sql = "INSERT INTO productos "
                   + "(nombre, precio, stock, id_proveedor) "
                   + "VALUES (?, ?, ?, ?)";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setDouble(2, precio);
            ps.setInt(3, stock);
            ps.setInt(4, idProveedor);

            return ps.executeUpdate();
        }
    }

    public String buscar(int id) throws SQLException {

        String sql = "SELECT * FROM productos WHERE id_producto=?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                return "ID Producto: " + rs.getInt("id_producto")
                        + "\nNombre: " + rs.getString("nombre")
                        + "\nPrecio: " + rs.getDouble("precio")
                        + "\nStock: " + rs.getInt("stock")
                        + "\nID Proveedor: "
                        + rs.getInt("id_proveedor");
            }

            return "No se encontró un producto con ese ID.";
        }
    }

    public int actualizar(int id, String nombre, double precio,
                          int stock, int idProveedor)
            throws SQLException {

        String sql = "UPDATE productos SET nombre=?, precio=?, "
                   + "stock=?, id_proveedor=? WHERE id_producto=?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setDouble(2, precio);
            ps.setInt(3, stock);
            ps.setInt(4, idProveedor);
            ps.setInt(5, id);

            return ps.executeUpdate();
        }
    }

    public int eliminar(int id) throws SQLException {

        String sql = "DELETE FROM productos WHERE id_producto=?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate();
        }
    }
}