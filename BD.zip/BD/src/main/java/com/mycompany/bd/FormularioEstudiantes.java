package com.mycompany.bd;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.sql.SQLException;

public class FormularioEstudiantes extends JFrame {

    JTextField txtId;
    JTextField txtNombre;
    JTextField txtApellido;
    JTextField txtCorreo;
    JTextArea areaResultado;

    EstudianteCRUD crud = new EstudianteCRUD();

    public FormularioEstudiantes() {

        setTitle("Gestión de Estudiantes");
        setSize(520, 530);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(43, 45, 66));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        panelFondo.setLayout(null);
        setContentPane(panelFondo);

        Font fuenteEtiquetas = new Font("Segoe UI", Font.BOLD, 12);
        Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 12);

        Color colorCamposFondo = new Color(30, 30, 30);
        Color colorCamposTexto = Color.WHITE;
        Color colorBordeCampos = new Color(43, 45, 66);

        JLabel titulo = new JLabel("GESTIÓN DE ESTUDIANTES",
                SwingConstants.CENTER);
        titulo.setBounds(20, 15, 460, 25);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(Color.WHITE);
        panelFondo.add(titulo);

        JLabel lblId = new JLabel("ID Estudiante:");
        lblId.setBounds(30, 60, 90, 25);
        lblId.setFont(fuenteEtiquetas);
        lblId.setForeground(Color.WHITE);
        panelFondo.add(lblId);

        txtId = new JTextField();
        txtId.setBounds(120, 60, 110, 28);
        txtId.setFont(fuenteCampos);
        txtId.setBackground(colorCamposFondo);
        txtId.setForeground(colorCamposTexto);
        txtId.setCaretColor(Color.WHITE);
        txtId.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtId);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 105, 80, 25);
        lblNombre.setFont(fuenteEtiquetas);
        lblNombre.setForeground(Color.WHITE);
        panelFondo.add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(120, 105, 350, 28);
        txtNombre.setFont(fuenteCampos);
        txtNombre.setBackground(colorCamposFondo);
        txtNombre.setForeground(colorCamposTexto);
        txtNombre.setCaretColor(Color.WHITE);
        txtNombre.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtNombre);

        JLabel lblApellido = new JLabel("Apellido:");
        lblApellido.setBounds(30, 150, 80, 25);
        lblApellido.setFont(fuenteEtiquetas);
        lblApellido.setForeground(Color.WHITE);
        panelFondo.add(lblApellido);

        txtApellido = new JTextField();
        txtApellido.setBounds(120, 150, 350, 28);
        txtApellido.setFont(fuenteCampos);
        txtApellido.setBackground(colorCamposFondo);
        txtApellido.setForeground(colorCamposTexto);
        txtApellido.setCaretColor(Color.WHITE);
        txtApellido.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtApellido);

        JLabel lblCorreo = new JLabel("Correo:");
        lblCorreo.setBounds(30, 195, 80, 25);
        lblCorreo.setFont(fuenteEtiquetas);
        lblCorreo.setForeground(Color.WHITE);
        panelFondo.add(lblCorreo);

        txtCorreo = new JTextField();
        txtCorreo.setBounds(120, 195, 350, 28);
        txtCorreo.setFont(fuenteCampos);
        txtCorreo.setBackground(colorCamposFondo);
        txtCorreo.setForeground(colorCamposTexto);
        txtCorreo.setCaretColor(Color.WHITE);
        txtCorreo.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtCorreo);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(30, 240, 100, 32);
        btnBuscar.setBackground(new Color(0, 119, 182));
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setFont(fuenteEtiquetas);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnBuscar);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(140, 240, 100, 32);
        btnGuardar.setBackground(new Color(40, 167, 69));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFont(fuenteEtiquetas);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnGuardar);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(250, 240, 110, 32);
        btnActualizar.setBackground(new Color(247, 127, 0));
        btnActualizar.setForeground(Color.WHITE);
        btnActualizar.setFont(fuenteEtiquetas);
        btnActualizar.setFocusPainted(false);
        btnActualizar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnActualizar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(370, 240, 100, 32);
        btnEliminar.setBackground(new Color(214, 40, 40));
        btnEliminar.setForeground(Color.WHITE);
        btnEliminar.setFont(fuenteEtiquetas);
        btnEliminar.setFocusPainted(false);
        btnEliminar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnEliminar);

        areaResultado = new JTextArea();
        areaResultado.setFont(new Font("Consolas", Font.PLAIN, 12));
        areaResultado.setLineWrap(true);
        areaResultado.setWrapStyleWord(true);
        areaResultado.setBackground(colorCamposFondo);
        areaResultado.setForeground(colorCamposTexto);
        areaResultado.setCaretColor(Color.WHITE);
        areaResultado.setBorder(new EmptyBorder(8, 8, 8, 8));

        JScrollPane scrollPane = new JScrollPane(areaResultado);
        scrollPane.setBounds(30, 295, 440, 170);
        scrollPane.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(scrollPane);

        btnGuardar.addActionListener(e -> ejecutarOperacion(() -> {

            if (txtNombre.getText().trim().isEmpty()) {
                areaResultado.setText("Ingrese el nombre del estudiante.");
                return;
            }

            int filas = crud.insertar(
                    txtNombre.getText(),
                    txtApellido.getText(),
                    txtCorreo.getText()
            );

            areaResultado.setText(filas > 0
                    ? "Estudiante guardado correctamente."
                    : "No se pudo guardar el estudiante.");
        }));

        btnBuscar.addActionListener(e -> ejecutarOperacion(() -> {
            areaResultado.setText(crud.buscar(leerId()));
        }));

        btnActualizar.addActionListener(e -> ejecutarOperacion(() -> {

            int filas = crud.actualizar(
                    leerId(),
                    txtNombre.getText(),
                    txtApellido.getText(),
                    txtCorreo.getText()
            );

            areaResultado.setText(filas > 0
                    ? "Estudiante actualizado correctamente."
                    : "No se encontró un estudiante con ese ID.");
        }));

        btnEliminar.addActionListener(e -> ejecutarOperacion(() -> {

            int filas = crud.eliminar(leerId());

            areaResultado.setText(filas > 0
                    ? "Estudiante eliminado correctamente."
                    : "No se encontró un estudiante con ese ID.");
        }));

        setVisible(true);
    }

    private int leerId() {
        int id = Integer.parseInt(txtId.getText().trim());

        if (id <= 0) {
            throw new NumberFormatException(
                    "El ID debe ser mayor que cero.");
        }

        return id;
    }

    private void ejecutarOperacion(Operacion operacion) {

        try {
            operacion.ejecutar();

        } catch (NumberFormatException e) {
            areaResultado.setText(
                    "Ingrese un ID válido (entero mayor que cero).");

        } catch (SQLException e) {
            areaResultado.setText(
                    "Error al acceder a la base de datos: "
                    + e.getMessage());
        }
    }

    @FunctionalInterface
    private interface Operacion {
        void ejecutar() throws SQLException;
    }
}