package com.mycompany.bd;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.sql.SQLException;

public class FormularioVentas extends JFrame {

    JTextField txtId;
    JTextField txtIdCliente;
    JTextField txtFecha;
    JTextField txtTotal;
    JTextArea areaResultado;

    VentaCRUD crud = new VentaCRUD();

    public FormularioVentas() {

        setTitle("Gestión de Ventas");
        setSize(520, 530);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(43, 45, 66));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        panelFondo.setLayout(null);
        setContentPane(panelFondo);

        Font fuenteEtiquetas = new Font("Segoe UI", Font.BOLD, 12);
        Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 12);

        Color colorTextoEtiquetas = Color.WHITE;
        Color colorCamposFondo = new Color(30, 30, 30);
        Color colorCamposTexto = Color.WHITE;
        Color colorBordeCampos = new Color(43, 45, 66);

        JLabel titulo = new JLabel(
                "GESTIÓN DE VENTAS",
                SwingConstants.CENTER
        );

        titulo.setBounds(20, 15, 460, 25);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(colorTextoEtiquetas);
        panelFondo.add(titulo);

        // ID VENTA

        JLabel lblId = new JLabel("ID Venta:");
        lblId.setBounds(30, 60, 80, 25);
        lblId.setFont(fuenteEtiquetas);
        lblId.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblId);

        txtId = new JTextField();
        txtId.setBounds(110, 60, 110, 28);
        txtId.setFont(fuenteCampos);
        txtId.setBackground(colorCamposFondo);
        txtId.setForeground(colorCamposTexto);
        txtId.setCaretColor(Color.WHITE);
        txtId.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtId);

        // ID CLIENTE

        JLabel lblIdCliente = new JLabel("ID Cliente:");
        lblIdCliente.setBounds(250, 60, 80, 25);
        lblIdCliente.setFont(fuenteEtiquetas);
        lblIdCliente.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblIdCliente);

        txtIdCliente = new JTextField();
        txtIdCliente.setBounds(330, 60, 140, 28);
        txtIdCliente.setFont(fuenteCampos);
        txtIdCliente.setBackground(colorCamposFondo);
        txtIdCliente.setForeground(colorCamposTexto);
        txtIdCliente.setCaretColor(Color.WHITE);
        txtIdCliente.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtIdCliente);

        // FECHA

        JLabel lblFecha = new JLabel("Fecha:");
        lblFecha.setBounds(30, 105, 80, 25);
        lblFecha.setFont(fuenteEtiquetas);
        lblFecha.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblFecha);

        txtFecha = new JTextField();
        txtFecha.setBounds(110, 105, 360, 28);
        txtFecha.setFont(fuenteCampos);
        txtFecha.setBackground(colorCamposFondo);
        txtFecha.setForeground(colorCamposTexto);
        txtFecha.setCaretColor(Color.WHITE);
        txtFecha.setBorder(new LineBorder(colorBordeCampos, 1));

        // La fecha se genera automáticamente en MySQL
        txtFecha.setEditable(false);

        panelFondo.add(txtFecha);

        // TOTAL

        JLabel lblTotal = new JLabel("Total:");
        lblTotal.setBounds(30, 150, 80, 25);
        lblTotal.setFont(fuenteEtiquetas);
        lblTotal.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblTotal);

        txtTotal = new JTextField();
        txtTotal.setBounds(110, 150, 360, 28);
        txtTotal.setFont(fuenteCampos);
        txtTotal.setBackground(colorCamposFondo);
        txtTotal.setForeground(colorCamposTexto);
        txtTotal.setCaretColor(Color.WHITE);
        txtTotal.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtTotal);

        // BOTÓN BUSCAR

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(30, 200, 100, 32);
        btnBuscar.setBackground(new Color(0, 119, 182));
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setFont(fuenteEtiquetas);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnBuscar);

        // BOTÓN GUARDAR

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(140, 200, 100, 32);
        btnGuardar.setBackground(new Color(40, 167, 69));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFont(fuenteEtiquetas);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnGuardar);

        // BOTÓN ACTUALIZAR

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(250, 200, 110, 32);
        btnActualizar.setBackground(new Color(247, 127, 0));
        btnActualizar.setForeground(Color.WHITE);
        btnActualizar.setFont(fuenteEtiquetas);
        btnActualizar.setFocusPainted(false);
        btnActualizar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnActualizar);

        // BOTÓN ELIMINAR

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(370, 200, 100, 32);
        btnEliminar.setBackground(new Color(214, 40, 40));
        btnEliminar.setForeground(Color.WHITE);
        btnEliminar.setFont(fuenteEtiquetas);
        btnEliminar.setFocusPainted(false);
        btnEliminar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnEliminar);

        // RESULTADO

        areaResultado = new JTextArea();
        areaResultado.setFont(new Font("Consolas", Font.PLAIN, 12));
        areaResultado.setLineWrap(true);
        areaResultado.setWrapStyleWord(true);
        areaResultado.setBackground(colorCamposFondo);
        areaResultado.setForeground(colorCamposTexto);
        areaResultado.setCaretColor(Color.WHITE);
        areaResultado.setBorder(new EmptyBorder(8, 8, 8, 8));

        JScrollPane scrollPane = new JScrollPane(areaResultado);
        scrollPane.setBounds(30, 255, 440, 210);
        scrollPane.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(scrollPane);

        // GUARDAR

        btnGuardar.addActionListener(e -> ejecutarOperacion(() -> {

            int idCliente = leerEntero(txtIdCliente);
            double total = leerDouble(txtTotal);

            int filas = crud.insertar(idCliente, total);

            areaResultado.setText(
                    filas > 0
                    ? "Venta guardada correctamente."
                    : "No se pudo guardar la venta."
            );
        }));

        // BUSCAR

        btnBuscar.addActionListener(e -> ejecutarOperacion(() -> {

            int id = leerId();

            areaResultado.setText(crud.buscar(id));
        }));

        // ACTUALIZAR

        btnActualizar.addActionListener(e -> ejecutarOperacion(() -> {

            int id = leerId();
            int idCliente = leerEntero(txtIdCliente);
            double total = leerDouble(txtTotal);

            int filas = crud.actualizar(
                    id,
                    idCliente,
                    total
            );

            areaResultado.setText(
                    filas > 0
                    ? "Venta actualizada correctamente."
                    : "No se encontró una venta con ese ID."
            );
        }));

        // ELIMINAR

        btnEliminar.addActionListener(e -> ejecutarOperacion(() -> {

            int id = leerId();

            int filas = crud.eliminar(id);

            areaResultado.setText(
                    filas > 0
                    ? "Venta eliminada correctamente."
                    : "No se encontró una venta con ese ID."
            );
        }));

        setVisible(true);
    }

    private int leerId() {

        int id = Integer.parseInt(txtId.getText().trim());

        if (id <= 0) {
            throw new NumberFormatException();
        }

        return id;
    }

    private int leerEntero(JTextField campo) {

        int valor = Integer.parseInt(campo.getText().trim());

        if (valor <= 0) {
            throw new NumberFormatException();
        }

        return valor;
    }

    private double leerDouble(JTextField campo) {

        double valor = Double.parseDouble(
                campo.getText().trim().replace(",", ".")
        );

        if (valor < 0) {
            throw new NumberFormatException();
        }

        return valor;
    }

    private void ejecutarOperacion(Operacion operacion) {

        try {

            operacion.ejecutar();

        } catch (NumberFormatException e) {

            areaResultado.setText(
                    "Ingrese valores numéricos válidos."
            );

        } catch (SQLException e) {

            areaResultado.setText(
                    "Error al acceder a la base de datos: "
                    + e.getMessage()
            );
        }
    }

    @FunctionalInterface
    private interface Operacion {
        void ejecutar() throws SQLException;
    }
}