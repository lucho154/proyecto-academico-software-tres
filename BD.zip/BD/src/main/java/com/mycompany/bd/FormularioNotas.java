package com.mycompany.bd;

import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;

public class FormularioNotas extends JFrame {

    JTextField txtIdCliente;
    JTextField txtTelefono;
    JTextField txtDireccion;
    JTextArea areaResultado;

    NotaClienteCRUD crud = new NotaClienteCRUD();

    public FormularioNotas() {
        // Configuración básica de la ventana
        setTitle("Notas del Cliente");
        setSize(520, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // ====================================================================
        //  PANEL PERSONALIZADO PARA PINTAR EL COLOR OSCURO DE FONDO
        // ====================================================================
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Usamos el mismo color azul grisáceo oscuro corporativo
                g.setColor(new Color(43, 45, 66));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        panelFondo.setLayout(null); // Diseño absoluto
        setContentPane(panelFondo); 
        // ====================================================================

        // Tipografía y Paleta de colores para el Dark Mode interno
        Font fuenteEtiquetas = new Font("Segoe UI", Font.BOLD, 12);
        Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 12);
        
        Color colorTextoEtiquetas = Color.WHITE;       // Letras de etiquetas blancas
        Color colorCamposFondo = new Color(30, 30, 30);  // Negro / Gris oscuro para las cajas
        Color colorCamposTexto = Color.WHITE;           // Texto blanco al escribir
        Color colorBordeCampos = new Color(43, 45, 66);  // Mismo color de fondo para fundir bordes

        // --- TITULO DE LA INTERFAZ ---
        JLabel titulo = new JLabel("NOTAS DEL CLIENTE", SwingConstants.CENTER);
        titulo.setBounds(20, 15, 460, 25);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(colorTextoEtiquetas);
        panelFondo.add(titulo);

        // --- FILA 1: ID CLIENTE Y TELÉFONO ---
        JLabel lblId = new JLabel("ID Cliente:");
        lblId.setBounds(30, 60, 80, 25);
        lblId.setFont(fuenteEtiquetas);
        lblId.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblId);

        txtIdCliente = new JTextField();
        txtIdCliente.setBounds(110, 60, 110, 28);
        txtIdCliente.setFont(fuenteCampos);
        txtIdCliente.setBackground(colorCamposFondo); // Fondo negro integrado
        txtIdCliente.setForeground(colorCamposTexto); // Letras blancas
        txtIdCliente.setCaretColor(Color.WHITE);      // Puntero blanco
        txtIdCliente.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtIdCliente);

        JLabel lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setBounds(250, 60, 70, 25);
        lblTelefono.setFont(fuenteEtiquetas);
        lblTelefono.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblTelefono);

        txtTelefono = new JTextField();
        txtTelefono.setBounds(320, 60, 150, 28);
        txtTelefono.setFont(fuenteCampos);
        txtTelefono.setBackground(colorCamposFondo); // Fondo negro integrado
        txtTelefono.setForeground(colorCamposTexto); // Letras blancas
        txtTelefono.setCaretColor(Color.WHITE);      // Puntero blanco
        txtTelefono.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtTelefono);

        // --- FILA 2: DIRECCIÓN (MÁS ANCHA) ---
        JLabel lblDireccion = new JLabel("Dirección:");
        lblDireccion.setBounds(30, 105, 80, 25);
        lblDireccion.setFont(fuenteEtiquetas);
        lblDireccion.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblDireccion);

        txtDireccion = new JTextField();
        txtDireccion.setBounds(110, 105, 360, 28);
        txtDireccion.setFont(fuenteCampos);
        txtDireccion.setBackground(colorCamposFondo); // Fondo negro integrado
        txtDireccion.setForeground(colorCamposTexto); // Letras blancas
        txtDireccion.setCaretColor(Color.WHITE);      // Puntero blanco
        txtDireccion.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtDireccion);


                // --- FILA 3: BOTONES DE ACCIÓN (ESTILO FLAT) ---
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(30, 155, 100, 32);
        btnBuscar.setBackground(new Color(0, 119, 182)); // Azul
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setFont(fuenteEtiquetas);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnBuscar);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(140, 155, 100, 32);
        btnGuardar.setBackground(new Color(40, 167, 69)); // Verde
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFont(fuenteEtiquetas);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnGuardar);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(250, 155, 110, 32);
        btnActualizar.setBackground(new Color(247, 127, 0)); // Naranja
        btnActualizar.setForeground(Color.WHITE);
        btnActualizar.setFont(fuenteEtiquetas);
        btnActualizar.setFocusPainted(false);
        btnActualizar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnActualizar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(370, 155, 100, 32);
        btnEliminar.setBackground(new Color(214, 40, 40)); // Rojo
        btnEliminar.setForeground(Color.WHITE);
        btnEliminar.setFont(fuenteEtiquetas);
        btnEliminar.setFocusPainted(false);
        btnEliminar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnEliminar);

        // --- FILA 4: ÁREA DE RESULTADOS (NEGRO INTEGRADO) ---
        areaResultado = new JTextArea();
        areaResultado.setFont(new Font("Consolas", Font.PLAIN, 12));
        areaResultado.setLineWrap(true);
        areaResultado.setWrapStyleWord(true);
        areaResultado.setBackground(colorCamposFondo); // Fondo negro integrado
        areaResultado.setForeground(colorCamposTexto); // Texto blanco
        areaResultado.setCaretColor(Color.WHITE);      // Puntero blanco
        areaResultado.setBorder(new EmptyBorder(8, 8, 8, 8)); // Margen interno

        JScrollPane scrollPane = new JScrollPane(areaResultado);
        scrollPane.setBounds(30, 210, 440, 220);
        scrollPane.setBorder(new LineBorder(colorBordeCampos, 1)); // Oculta bordes blancos externos
        panelFondo.add(scrollPane);

        // ==========================================
        //         LÓGICA DE EVENTOS (INTEGRADA)
        // ==========================================

        // GUARDAR
        btnGuardar.addActionListener(e -> ejecutarOperacion(() -> {
            int filas = crud.insertar(
                    leerIdCliente(),
                    txtTelefono.getText(),
                    txtDireccion.getText()
            );
            areaResultado.setText(filas > 0
                    ? "Nota guardada correctamente."
                    : "No se pudo guardar la nota.");
        }));

        // BUSCAR
        btnBuscar.addActionListener(e -> ejecutarOperacion(() -> {
            areaResultado.setText(crud.buscar(leerIdCliente()));
        }));

        // ACTUALIZAR
        btnActualizar.addActionListener(e -> ejecutarOperacion(() -> {
            int filas = crud.actualizar(
                    leerIdCliente(),
                    txtTelefono.getText(),
                    txtDireccion.getText()
            );
            areaResultado.setText(filas > 0
                    ? "Nota actualizada correctamente."
                    : "No se encontró una nota para ese cliente.");
        }));

        // ELIMINAR
        btnEliminar.addActionListener(e -> ejecutarOperacion(() -> {
            int filas = crud.eliminar(leerIdCliente());
            areaResultado.setText(filas > 0
                    ? "Nota eliminada correctamente."
                    : "No se encontró una nota para ese cliente.");
        }));

        setVisible(true);
    }

    private int leerIdCliente() {
        String idTexto = txtIdCliente.getText().trim();
        int idCliente = Integer.parseInt(idTexto);
        if (idCliente <= 0) {
            throw new NumberFormatException("El ID debe ser mayor que cero.");
        }
        return idCliente;
    }

    private void ejecutarOperacion(Operacion operacion) {
        try {
            operacion.ejecutar();
        } catch (NumberFormatException e) {
            areaResultado.setText("Ingrese un ID de cliente válido (entero mayor que cero).");
        } catch (SQLException e) {
            areaResultado.setText("Error al acceder a la base de datos: " + e.getMessage());
        }
    }

    @FunctionalInterface
    private interface Operacion {
        void ejecutar() throws SQLException;
    }
}
