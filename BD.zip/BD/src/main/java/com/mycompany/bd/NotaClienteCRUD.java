package com.mycompany.bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class NotaClienteCRUD {

    public int insertar(
            int idCliente,
            String telefono,
            String direccion) throws SQLException {

        String sql =
                "INSERT INTO notas_cliente "
                + "(id_cliente, telefono_nota, direccion_nota) "
                + "VALUES (?, ?, ?)";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCliente);
            ps.setString(2, telefono);
            ps.setString(3, direccion);
            return ps.executeUpdate();
        }
    }

    public String buscar(int idCliente) throws SQLException {

        String sql =
                "SELECT * FROM notas_cliente "
                + "WHERE id_cliente = ?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCliente);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return "ID Nota: "
                            + rs.getInt("id_nota")
                            + "\nID Cliente: "
                            + rs.getInt("id_cliente")
                            + "\nTeléfono: "
                            + rs.getString("telefono_nota")
                            + "\nDirección: "
                            + rs.getString("direccion_nota");
                }
            }
        }

        return "Nota no encontrada";
    }

    public int actualizar(
            int idCliente,
            String telefono,
            String direccion) throws SQLException {

        String sql =
                "UPDATE notas_cliente SET "
                + "telefono_nota = ?, "
                + "direccion_nota = ? "
                + "WHERE id_cliente = ?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, telefono);
            ps.setString(2, direccion);
            ps.setInt(3, idCliente);
            return ps.executeUpdate();
        }
    }

    public int eliminar(int idCliente) throws SQLException {

        String sql =
                "DELETE FROM notas_cliente "
                + "WHERE id_cliente = ?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCliente);
            return ps.executeUpdate();
        }
    }
}