package com.mycompany.bd;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.sql.SQLException;

public class FormularioProveedores extends JFrame {

    JTextField txtId;
    JTextField txtNombre;
    JTextField txtTelefono;
    JTextField txtCorreo;
    JTextArea areaResultado;

    ProveedorCRUD crud = new ProveedorCRUD();

    public FormularioProveedores() {

        setTitle("Gestión de Proveedores");
        setSize(520, 530);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(43, 45, 66));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        panelFondo.setLayout(null);
        setContentPane(panelFondo);

        Font fuenteEtiquetas = new Font("Segoe UI", Font.BOLD, 12);
        Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 12);

        Color fondoCampos = new Color(30, 30, 30);

        JLabel titulo = new JLabel(
                "GESTIÓN DE PROVEEDORES",
                SwingConstants.CENTER);

        titulo.setBounds(20, 15, 460, 25);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(Color.WHITE);
        panelFondo.add(titulo);

        JLabel lblId = new JLabel("ID Proveedor:");
        lblId.setBounds(30, 60, 90, 25);
        lblId.setFont(fuenteEtiquetas);
        lblId.setForeground(Color.WHITE);
        panelFondo.add(lblId);

        txtId = crearCampo(120, 60, 110, fondoCampos, fuenteCampos);
        panelFondo.add(txtId);

        JLabel lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setBounds(250, 60, 70, 25);
        lblTelefono.setFont(fuenteEtiquetas);
        lblTelefono.setForeground(Color.WHITE);
        panelFondo.add(lblTelefono);

        txtTelefono = crearCampo(320, 60, 150, fondoCampos, fuenteCampos);
        panelFondo.add(txtTelefono);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 105, 80, 25);
        lblNombre.setFont(fuenteEtiquetas);
        lblNombre.setForeground(Color.WHITE);
        panelFondo.add(lblNombre);

        txtNombre = crearCampo(120, 105, 350, fondoCampos, fuenteCampos);
        panelFondo.add(txtNombre);

        JLabel lblCorreo = new JLabel("Correo:");
        lblCorreo.setBounds(30, 150, 80, 25);
        lblCorreo.setFont(fuenteEtiquetas);
        lblCorreo.setForeground(Color.WHITE);
        panelFondo.add(lblCorreo);

        txtCorreo = crearCampo(120, 150, 350, fondoCampos, fuenteCampos);
        panelFondo.add(txtCorreo);

        JButton btnBuscar = crearBoton(
                "Buscar", 30, 200, 100,
                new Color(0, 119, 182), fuenteEtiquetas);

        JButton btnGuardar = crearBoton(
                "Guardar", 140, 200, 100,
                new Color(40, 167, 69), fuenteEtiquetas);

        JButton btnActualizar = crearBoton(
                "Actualizar", 250, 200, 110,
                new Color(247, 127, 0), fuenteEtiquetas);

        JButton btnEliminar = crearBoton(
                "Eliminar", 370, 200, 100,
                new Color(214, 40, 40), fuenteEtiquetas);

        panelFondo.add(btnBuscar);
        panelFondo.add(btnGuardar);
        panelFondo.add(btnActualizar);
        panelFondo.add(btnEliminar);

        areaResultado = new JTextArea();
        areaResultado.setFont(new Font("Consolas", Font.PLAIN, 12));
        areaResultado.setLineWrap(true);
        areaResultado.setWrapStyleWord(true);
        areaResultado.setBackground(fondoCampos);
        areaResultado.setForeground(Color.WHITE);
        areaResultado.setCaretColor(Color.WHITE);
        areaResultado.setBorder(new EmptyBorder(8, 8, 8, 8));

        JScrollPane scrollPane = new JScrollPane(areaResultado);
        scrollPane.setBounds(30, 255, 440, 210);
        scrollPane.setBorder(new LineBorder(
                new Color(43, 45, 66), 1));

        panelFondo.add(scrollPane);

        btnGuardar.addActionListener(e -> ejecutarOperacion(() -> {

            if (txtNombre.getText().trim().isEmpty()) {
                areaResultado.setText(
                        "Ingrese el nombre del proveedor.");
                return;
            }

            int filas = crud.insertar(
                    txtNombre.getText(),
                    txtTelefono.getText(),
                    txtCorreo.getText()
            );

            areaResultado.setText(filas > 0
                    ? "Proveedor guardado correctamente."
                    : "No se pudo guardar el proveedor.");
        }));

        btnBuscar.addActionListener(e -> ejecutarOperacion(() -> {
            areaResultado.setText(crud.buscar(leerId()));
        }));

        btnActualizar.addActionListener(e -> ejecutarOperacion(() -> {

            int filas = crud.actualizar(
                    leerId(),
                    txtNombre.getText(),
                    txtTelefono.getText(),
                    txtCorreo.getText()
            );

            areaResultado.setText(filas > 0
                    ? "Proveedor actualizado correctamente."
                    : "No se encontró un proveedor con ese ID.");
        }));

        btnEliminar.addActionListener(e -> ejecutarOperacion(() -> {

            int filas = crud.eliminar(leerId());

            areaResultado.setText(filas > 0
                    ? "Proveedor eliminado correctamente."
                    : "No se encontró un proveedor con ese ID.");
        }));

        setVisible(true);
    }

    private JTextField crearCampo(
            int x, int y, int ancho,
            Color fondo, Font fuente) {

        JTextField campo = new JTextField();

        campo.setBounds(x, y, ancho, 28);
        campo.setFont(fuente);
        campo.setBackground(fondo);
        campo.setForeground(Color.WHITE);
        campo.setCaretColor(Color.WHITE);
        campo.setBorder(new LineBorder(
                new Color(43, 45, 66), 1));

        return campo;
    }

    private JButton crearBoton(
            String texto, int x, int y, int ancho,
            Color color, Font fuente) {

        JButton boton = new JButton(texto);

        boton.setBounds(x, y, ancho, 32);
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFont(fuente);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createEmptyBorder());

        return boton;
    }

    private int leerId() {

        int id = Integer.parseInt(txtId.getText().trim());

        if (id <= 0) {
            throw new NumberFormatException(
                    "El ID debe ser mayor que cero.");
        }

        return id;
    }

    private void ejecutarOperacion(Operacion operacion) {

        try {
            operacion.ejecutar();

        } catch (NumberFormatException e) {

            areaResultado.setText(
                    "Ingrese un ID válido (entero mayor que cero).");

        } catch (SQLException e) {

            areaResultado.setText(
                    "Error al acceder a la base de datos: "
                    + e.getMessage());
        }
    }

    @FunctionalInterface
    private interface Operacion {
        void ejecutar() throws SQLException;
    }
}