package com.mycompany.bd;

import javax.swing.*;
import java.awt.*;

public class BD extends JFrame {

    public BD() {

        // Configuración básica del menú principal
        setTitle("Sistema CRUD");
        setSize(500, 420);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel principal
        JPanel panelMenu = new JPanel();
        panelMenu.setBackground(new Color(20, 20, 20));
        panelMenu.setLayout(null);
        setContentPane(panelMenu);

        // TÍTULO
        JLabel titulo = new JLabel(
                "SISTEMA DE BASE DE DATOS",
                SwingConstants.CENTER
        );

        titulo.setBounds(20, 30, 460, 30);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setForeground(Color.WHITE);
        panelMenu.add(titulo);

        // -------------------------
        // BOTÓN CLIENTES
        // -------------------------

        JButton btnClientes = new JButton("Clientes");

        btnClientes.setBounds(50, 100, 180, 45);
        btnClientes.setBackground(new Color(43, 45, 66));
        btnClientes.setForeground(Color.WHITE);
        btnClientes.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnClientes.setFocusPainted(false);
        btnClientes.setBorder(BorderFactory.createEmptyBorder());

        panelMenu.add(btnClientes);

        // -------------------------
        // BOTÓN NOTAS CLIENTE
        // -------------------------

        JButton btnNotas = new JButton("Notas Cliente");

        btnNotas.setBounds(270, 100, 180, 45);
        btnNotas.setBackground(new Color(0, 119, 182));
        btnNotas.setForeground(Color.WHITE);
        btnNotas.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnNotas.setFocusPainted(false);
        btnNotas.setBorder(BorderFactory.createEmptyBorder());

        panelMenu.add(btnNotas);

        // -------------------------
        // BOTÓN ESTUDIANTES
        // -------------------------

        JButton btnEstudiantes = new JButton("Estudiantes");

        btnEstudiantes.setBounds(50, 170, 180, 45);
        btnEstudiantes.setBackground(new Color(40, 167, 69));
        btnEstudiantes.setForeground(Color.WHITE);
        btnEstudiantes.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnEstudiantes.setFocusPainted(false);
        btnEstudiantes.setBorder(BorderFactory.createEmptyBorder());

        panelMenu.add(btnEstudiantes);

        // -------------------------
        // BOTÓN PROVEEDORES
        // -------------------------

        JButton btnProveedores = new JButton("Proveedores");

        btnProveedores.setBounds(270, 170, 180, 45);
        btnProveedores.setBackground(new Color(247, 127, 0));
        btnProveedores.setForeground(Color.WHITE);
        btnProveedores.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnProveedores.setFocusPainted(false);
        btnProveedores.setBorder(BorderFactory.createEmptyBorder());

        panelMenu.add(btnProveedores);

        // -------------------------
        // BOTÓN PRODUCTOS
        // -------------------------

        JButton btnProductos = new JButton("Productos");

        btnProductos.setBounds(160, 240, 180, 45);
        btnProductos.setBackground(new Color(214, 40, 40));
        btnProductos.setForeground(Color.WHITE);
        btnProductos.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnProductos.setFocusPainted(false);
        btnProductos.setBorder(BorderFactory.createEmptyBorder());

        panelMenu.add(btnProductos);

        // -------------------------
        // BOTÓN VENTAS
        // -------------------------

        JButton btnVentas = new JButton("Ventas");

        btnVentas.setBounds(50, 310, 180, 45);
        btnVentas.setBackground(new Color(0, 119, 182));
        btnVentas.setForeground(Color.WHITE);
        btnVentas.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnVentas.setFocusPainted(false);
        btnVentas.setBorder(BorderFactory.createEmptyBorder());

        panelMenu.add(btnVentas);

        // -------------------------
        // BOTÓN DETALLE VENTAS
        // -------------------------

        JButton btnDetalleVentas = new JButton("Detalle Ventas");

        btnDetalleVentas.setBounds(270, 310, 180, 45);
        btnDetalleVentas.setBackground(new Color(40, 167, 69));
        btnDetalleVentas.setForeground(Color.WHITE);
        btnDetalleVentas.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnDetalleVentas.setFocusPainted(false);
        btnDetalleVentas.setBorder(BorderFactory.createEmptyBorder());

        panelMenu.add(btnDetalleVentas);

        // -------------------------
        // ACCIONES
        // -------------------------

        btnClientes.addActionListener(e ->
                new FormularioClientes()
        );

        btnNotas.addActionListener(e ->
                new FormularioNotas()
        );

        btnEstudiantes.addActionListener(e ->
                new FormularioEstudiantes()
        );

        btnProveedores.addActionListener(e ->
                new FormularioProveedores()
        );

        btnProductos.addActionListener(e ->
                new FormularioProductos()
        );

        btnVentas.addActionListener(e ->
                new FormularioVentas()
        );

        btnDetalleVentas.addActionListener(e ->
                new FormularioVentasDetalle()
        );

        setVisible(true);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() ->
                new BD()
        );
    }
}