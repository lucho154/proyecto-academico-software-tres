package com.mycompany.bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClienteCRUD {

    public int insertar(String nombre, String telefono, String correo)
            throws SQLException {
        String sql = """
                INSERT INTO clientes(nombre, telefono, correo)
                VALUES (?, ?, ?)
                """;

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setString(2, telefono);
            ps.setString(3, correo);
            return ps.executeUpdate();
        }
    }

    public String buscar(int id) throws SQLException {
        String sql = "SELECT * FROM clientes WHERE id_cliente = ?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return "ID: " + rs.getInt("id_cliente")
                            + "\nNombre: " + rs.getString("nombre")
                            + "\nTeléfono: " + rs.getString("telefono")
                            + "\nCorreo: " + rs.getString("correo");
                }
            }
        }

        return "Cliente no encontrado";
    }

    public int actualizar(
            int id,
            String nombre,
            String telefono,
            String correo) throws SQLException {
        String sql = "UPDATE clientes SET "
                + "nombre = ?, "
                + "telefono = ?, "
                + "correo = ? "
                + "WHERE id_cliente = ?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setString(2, telefono);
            ps.setString(3, correo);
            ps.setInt(4, id);
            return ps.executeUpdate();
        }
    }

    public int eliminar(int id) throws SQLException {
        String sql = "DELETE FROM clientes WHERE id_cliente = ?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }
}