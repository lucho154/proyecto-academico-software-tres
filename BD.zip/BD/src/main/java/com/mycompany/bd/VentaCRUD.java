package com.mycompany.bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VentaCRUD {

    public int insertar(int idCliente, double total) throws SQLException {

        String sql = "INSERT INTO ventas (id_cliente, total) VALUES (?, ?)";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCliente);
            ps.setDouble(2, total);

            return ps.executeUpdate();
        }
    }

    public String buscar(int id) throws SQLException {

        String sql = "SELECT * FROM ventas WHERE id_venta=?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                return "ID Venta: " + rs.getInt("id_venta")
                        + "\nID Cliente: " + rs.getInt("id_cliente")
                        + "\nFecha: " + rs.getString("fecha")
                        + "\nTotal: " + rs.getDouble("total");
            }

            return "No se encontró una venta con ese ID.";
        }
    }

    public int actualizar(int id, int idCliente, double total)
            throws SQLException {

        String sql = "UPDATE ventas SET id_cliente=?, total=? "
                   + "WHERE id_venta=?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCliente);
            ps.setDouble(2, total);
            ps.setInt(3, id);

            return ps.executeUpdate();
        }
    }

    public int eliminar(int id) throws SQLException {

        String sql = "DELETE FROM ventas WHERE id_venta=?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate();
        }
    }
}