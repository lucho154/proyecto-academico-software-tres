package com.mycompany.bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EstudianteCRUD {

    public int insertar(String nombre, String apellido, String correo) throws SQLException {

        String sql = "INSERT INTO estudiantes (nombre, apellido, correo) VALUES (?, ?, ?)";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setString(2, apellido);
            ps.setString(3, correo);

            return ps.executeUpdate();
        }
    }

    public String buscar(int id) throws SQLException {

        String sql = "SELECT * FROM estudiantes WHERE id_estudiante = ?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return "ID Estudiante: " + rs.getInt("id_estudiante")
                        + "\nNombre: " + rs.getString("nombre")
                        + "\nApellido: " + rs.getString("apellido")
                        + "\nCorreo: " + rs.getString("correo");
            }

            return "No se encontró un estudiante con ese ID.";
        }
    }

    public int actualizar(int id, String nombre, String apellido, String correo)
            throws SQLException {

        String sql = "UPDATE estudiantes SET nombre=?, apellido=?, correo=? "
                   + "WHERE id_estudiante=?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setString(2, apellido);
            ps.setString(3, correo);
            ps.setInt(4, id);

            return ps.executeUpdate();
        }
    }

    public int eliminar(int id) throws SQLException {

        String sql = "DELETE FROM estudiantes WHERE id_estudiante=?";

        try (Connection con = ConexionMySQL.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate();
        }
    }
}