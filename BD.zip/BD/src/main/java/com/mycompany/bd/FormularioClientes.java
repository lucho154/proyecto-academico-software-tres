package com.mycompany.bd;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.sql.SQLException;

public class FormularioClientes extends JFrame {

    JTextField txtId;
    JTextField txtNombre;
    JTextField txtTelefono;
    JTextField txtCorreo;
    JTextArea areaResultado;

    ClienteCRUD crud = new ClienteCRUD();

    public FormularioClientes() {
        // Configuración básica de la ventana principal
        setTitle("Gestión de Clientes");
        setSize(520, 530); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // ====================================================================
        //  PANEL PERSONALIZADO PARA PINTAR EL COLOR OSCURO DE FONDO
        // ====================================================================
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Mantenemos el color azul grisáceo oscuro corporativo que te gustó
                g.setColor(new Color(43, 45, 66));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        panelFondo.setLayout(null); // Diseño absoluto para acomodar todo manualmente
        setContentPane(panelFondo); 
        // ====================================================================

        // Configuración de fuentes y paleta de colores para el Dark Mode interno
        Font fuenteEtiquetas = new Font("Segoe UI", Font.BOLD, 12);
        Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 12);
        Color colorTextoEtiquetas = Color.WHITE; 
        
        Color colorCamposFondo = new Color(30, 30, 30);  // Negro / Gris oscuro para las cajas
        Color colorCamposTexto = Color.WHITE;           // Letras blancas al escribir
        Color colorBordeCampos = new Color(43, 45, 66);  // Mismo color de fondo para borrar bordes blancos

        // --- TITULO DE LA INTERFAZ ---
        JLabel titulo = new JLabel("GESTIÓN DE CLIENTES", SwingConstants.CENTER);
        titulo.setBounds(20, 15, 460, 25);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(colorTextoEtiquetas);
        panelFondo.add(titulo);

        // --- FILA 1: ID CLIENTE Y TELÉFONO ---
        JLabel lblId = new JLabel("ID Cliente:");
        lblId.setBounds(30, 60, 80, 25);
        lblId.setFont(fuenteEtiquetas);
        lblId.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblId);

        txtId = new JTextField();
        txtId.setBounds(110, 60, 110, 28);
        txtId.setFont(fuenteCampos);
        txtId.setBackground(colorCamposFondo); // Fondo negro integrado
        txtId.setForeground(colorCamposTexto); // Texto blanco
        txtId.setCaretColor(Color.WHITE);      // Puntero de escritura blanco
        txtId.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtId);

        JLabel lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setBounds(250, 60, 70, 25);
        lblTelefono.setFont(fuenteEtiquetas);
        lblTelefono.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblTelefono);

        txtTelefono = new JTextField();
        txtTelefono.setBounds(320, 60, 150, 28);
        txtTelefono.setFont(fuenteCampos);
        txtTelefono.setBackground(colorCamposFondo); // Fondo negro integrado
        txtTelefono.setForeground(colorCamposTexto); // Texto blanco
        txtTelefono.setCaretColor(Color.WHITE);      // Puntero de escritura blanco
        txtTelefono.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtTelefono);

        // --- FILA 2: NOMBRE ---
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 105, 80, 25);
        lblNombre.setFont(fuenteEtiquetas);
        lblNombre.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(110, 105, 360, 28);
        txtNombre.setFont(fuenteCampos);
        txtNombre.setBackground(colorCamposFondo); // Fondo negro integrado
        txtNombre.setForeground(colorCamposTexto); // Texto blanco
        txtNombre.setCaretColor(Color.WHITE);      // Puntero de escritura blanco
        txtNombre.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtNombre);

        // --- FILA 3: CORREO ---
        JLabel lblCorreo = new JLabel("Correo:");
        lblCorreo.setBounds(30, 150, 80, 25);
        lblCorreo.setFont(fuenteEtiquetas);
        lblCorreo.setForeground(colorTextoEtiquetas);
        panelFondo.add(lblCorreo);

        txtCorreo = new JTextField();
        txtCorreo.setBounds(110, 150, 360, 28);
        txtCorreo.setFont(fuenteCampos);
        txtCorreo.setBackground(colorCamposFondo); // Fondo negro integrado
        txtCorreo.setForeground(colorCamposTexto); // Texto blanco
        txtCorreo.setCaretColor(Color.WHITE);      // Puntero de escritura blanco
        txtCorreo.setBorder(new LineBorder(colorBordeCampos, 1));
        panelFondo.add(txtCorreo);


                // --- FILA 4: BOTONES DE ACCIÓN (ESTILO FLAT) ---
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(30, 200, 100, 32);
        btnBuscar.setBackground(new Color(0, 119, 182)); // Azul
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setFont(fuenteEtiquetas);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnBuscar);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(140, 200, 100, 32);
        btnGuardar.setBackground(new Color(40, 167, 69)); // Verde
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFont(fuenteEtiquetas);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnGuardar);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(250, 200, 110, 32);
        btnActualizar.setBackground(new Color(247, 127, 0)); // Naranja
        btnActualizar.setForeground(Color.WHITE);
        btnActualizar.setFont(fuenteEtiquetas);
        btnActualizar.setFocusPainted(false);
        btnActualizar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnActualizar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(370, 200, 100, 32);
        btnEliminar.setBackground(new Color(214, 40, 40)); // Rojo
        btnEliminar.setForeground(Color.WHITE);
        btnEliminar.setFont(fuenteEtiquetas);
        btnEliminar.setFocusPainted(false);
        btnEliminar.setBorder(BorderFactory.createEmptyBorder());
        panelFondo.add(btnEliminar);

        // --- FILA 5: ÁREA DE RESULTADOS (NEGRO INTEGRADO) ---
        areaResultado = new JTextArea();
        areaResultado.setFont(new Font("Consolas", Font.PLAIN, 12));
        areaResultado.setLineWrap(true);
        areaResultado.setWrapStyleWord(true);
        areaResultado.setBackground(colorCamposFondo); // Fondo negro integrado
        areaResultado.setForeground(colorCamposTexto); // Texto blanco
        areaResultado.setCaretColor(Color.WHITE);      // Puntero de escritura blanco
        areaResultado.setBorder(new EmptyBorder(8, 8, 8, 8)); // Espaciado interno para el texto

        JScrollPane scrollPane = new JScrollPane(areaResultado);
        scrollPane.setBounds(30, 255, 440, 210);
        scrollPane.setBorder(new LineBorder(colorBordeCampos, 1)); // Borra líneas blancas del borde externo
        panelFondo.add(scrollPane);

        // ==========================================
        //         LÓGICA DE EVENTOS INTEGRADA
        // ==========================================

        // GUARDAR
        btnGuardar.addActionListener(e -> ejecutarOperacion(() -> {
            if (txtNombre.getText().trim().isEmpty()) {
                areaResultado.setText("Ingrese el nombre del cliente.");
                return;
            }
            int filas = crud.insertar(
                    txtNombre.getText(),
                    txtTelefono.getText(),
                    txtCorreo.getText()
            );
            areaResultado.setText(filas > 0
                    ? "Cliente guardado correctamente."
                    : "No se pudo guardar el cliente.");
        }));

        // BUSCAR
        btnBuscar.addActionListener(e -> ejecutarOperacion(() -> {
            areaResultado.setText(crud.buscar(leerId()));
        }));

        // ACTUALIZAR
        btnActualizar.addActionListener(e -> ejecutarOperacion(() -> {
            int filas = crud.actualizar(
                    leerId(),
                    txtNombre.getText(),
                    txtTelefono.getText(),
                    txtCorreo.getText()
            );
            areaResultado.setText(filas > 0
                    ? "Cliente actualizado correctamente."
                    : "No se encontró un cliente con ese ID.");
        }));

        // ELIMINAR
        btnEliminar.addActionListener(e -> ejecutarOperacion(() -> {
            int filas = crud.eliminar(leerId());
            areaResultado.setText(filas > 0
                    ? "Cliente eliminado correctamente."
                    : "No se encontró un cliente con ese ID.");
        }));

        setVisible(true);
    }

    private int leerId() {
        int id = Integer.parseInt(txtId.getText().trim());
        if (id <= 0) {
            throw new NumberFormatException("El ID debe ser mayor que cero.");
        }
        return id;
    }

    private void ejecutarOperacion(Operacion operacion) {
        try {
            operacion.ejecutar();
        } catch (NumberFormatException e) {
            areaResultado.setText("Ingrese un ID válido (entero mayor que cero).");
        } catch (SQLException e) {
            areaResultado.setText("Error al acceder a la base de datos: " + e.getMessage());
        }
    }

    @FunctionalInterface
    private interface Operacion {
        void ejecutar() throws SQLException;
    }
}
