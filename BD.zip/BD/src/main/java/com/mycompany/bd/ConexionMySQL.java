package com.mycompany.bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionMySQL {

    public static Connection conectar() throws SQLException {

        String url = "jdbc:mysql://localhost:3306/ejemplolpa2";

        String usuario = "root";
        String contraseña = "123456789";

        return DriverManager.getConnection(
                url,
                usuario,
                contraseña
        );
    }
}