<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#101827">
    <title>Crear gestor · Clave segura</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <main class="page">
        <header class="topbar">
            <a class="brand" href="../index.php"><span class="brand-icon" aria-hidden="true">◆</span><span>Clave<span class="brand-light"> segura</span></span></a>
        </header>
        <section id="notice" class="notice hidden" role="alert"></section>
        <section class="panel auth-panel">
            <div id="registration-open">
                <div class="eyebrow">REGISTRO</div>
                <h1>Crea tu cuenta</h1>
                <p>Registra un usuario y una contraseña para entrar al gestor.</p>
                <form id="auth-form" data-mode="setup">
                    <label for="username">Nombre de usuario</label>
                    <input id="username" type="text" autocomplete="username" minlength="3" maxlength="80" pattern="[\p{L}\p{N}_.@-]+" title="Usa letras, números, punto, guion, guion bajo o @" required>
                    <label for="master-password">Contraseña de acceso</label>
                    <input id="master-password" type="password" autocomplete="new-password" minlength="12" required>
                    <div class="field">
                        <label for="master-confirm">Confirma la contraseña</label>
                        <input id="master-confirm" type="password" autocomplete="new-password" minlength="12" required>
                    </div>
                    <p class="hint">Usa al menos 12 caracteres. Al registrarte, irás al inicio de sesión para entrar con estos mismos datos.</p>
                    <button class="button button-primary button-wide" type="submit">Crear cuenta</button>
                </form>
            </div>
            <p id="registration-login-link" class="auth-link">¿Ya tienes cuenta? <a href="login.php">Iniciar sesión</a></p>
        </section>
        <footer>Gestor local · MySQL de XAMPP · Claves cifradas con AES-256-GCM</footer>
    </main>
    <script src="../app.js" defer></script>
</body>
</html>
