<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#101827">
    <title>Mi bóveda · Clave segura</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <main class="page">
        <header class="topbar">
            <a class="brand" href="../index.php"><span class="brand-icon" aria-hidden="true">◆</span><span>Clave<span class="brand-light"> segura</span></span></a>
            <div class="account-actions">
                <span id="current-username" class="current-username" aria-label="Usuario conectado"></span>
                <button id="logout-button" class="button button-quiet" type="button">Cerrar sesión</button>
            </div>
        </header>
        <section id="notice" class="notice hidden" role="alert"></section>
        <section id="vault-panel">
            <div class="intro">
                <div>
                    <div class="eyebrow">ALMACENAMIENTO CIFRADO</div>
                    <h1>Tus contraseñas, bajo control.</h1>
                    <p>Las claves se cifran antes de guardarse en la base de datos.</p>
                </div>
                <span class="lock-badge">● Bóveda desbloqueada</span>
            </div>
            <section class="panel form-panel generator-panel">
                <div class="section-heading">
                    <div><div class="eyebrow">GENERADOR SEGURO</div><h2>Genera una contraseña por categoría</h2></div>
                </div>
                <div class="generator-row">
                    <div class="field">
                        <label for="generator-category">Categoría</label>
                        <select id="generator-category" class="text-input">
                            <option>Redes sociales</option>
                            <option>Banco</option>
                            <option selected>Personal</option>
                            <option>Trabajo</option>
                            <option>Juegos</option>
                            <option>Otro</option>
                        </select>
                    </div>
                    <button id="generate-button" class="button button-primary generator-button" type="button">Generar y cifrar</button>
                </div>
                <div class="generated-row">
                    <input id="generated-password" class="password-monospace" type="text" readonly aria-label="Contraseña generada cifrada">
                    <button id="use-generated-button" class="button button-secondary" type="button">Usar para guardar</button>
                </div>
                <p class="hint">Cada contraseña generada queda cifrada en el historial. Elige una categoría para ajustar su longitud.</p>
            </section>

            <section class="panel form-panel">
                <div class="section-heading">
                    <div><div class="eyebrow">NUEVA CREDENCIAL</div><h2>Guardar una contraseña</h2></div>
                </div>
                <form id="credential-form">
                    <div class="form-grid">
                        <div class="field field-wide">
                            <label for="service">Servicio o sitio *</label>
                            <input id="service" name="service" maxlength="120" placeholder="Ej. Correo personal" required>
                        </div>
                        <div class="field">
                            <label for="category">Categoría *</label>
                            <select id="category" name="category" class="text-input" required>
                                <option>Redes sociales</option>
                                <option>Banco</option>
                                <option selected>Personal</option>
                                <option>Trabajo</option>
                                <option>Juegos</option>
                                <option>Otro</option>
                            </select>
                        </div>
                        <div class="field">
                            <label for="username">Usuario o correo</label>
                            <input id="username" name="username" maxlength="190" autocomplete="username" placeholder="nombre@ejemplo.com">
                        </div>
                        <div class="field">
                            <label for="url">Sitio web</label>
                            <input id="url" name="url" maxlength="500" type="url" placeholder="https://ejemplo.com">
                        </div>
                        <div class="field field-wide">
                            <label for="credential-password">Contraseña *</label>
                            <div class="password-entry">
                                <input id="credential-password" name="password" type="password" maxlength="4096" autocomplete="new-password" required>
                            </div>
                        </div>
                    </div>
                    <button class="button button-primary" type="submit">Guardar credencial</button>
                </form>
            </section>
            <section class="vault-section">
                <div class="section-heading">
                    <div><div class="eyebrow">HISTORIAL CIFRADO</div><h2>Credenciales y contraseñas <span id="history-count" class="count"></span></h2></div>
                </div>
                <div id="history-empty" class="panel empty-state hidden">
                    <span class="empty-icon" aria-hidden="true">◇</span>
                    <h3>El historial está vacío</h3>
                    <p>Las credenciales guardadas y las contraseñas generadas aparecerán aquí, cifradas.</p>
                </div>
                <div id="history-list" class="credential-list"></div>
            </section>
        </section>
        <footer>Gestor local · MySQL de XAMPP · Claves cifradas con AES-256-GCM</footer>
    </main>
    <script src="../app.js?v=20261024-7" defer></script>
</body>
</html>
