<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#101827">
    <title>Desbloquear · Clave segura</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <main class="page">
        <header class="topbar">
            <a class="brand" href="../index.php"><span class="brand-icon" aria-hidden="true">◆</span><span>Clave<span class="brand-light"> segura</span></span></a>
        </header>
        <section id="notice" class="notice hidden" role="alert"></section>
        <section class="panel auth-panel">
            <div class="eyebrow">TU ESPACIO PRIVADO</div>
            <h1>Desbloquea tu gestor</h1>
            <p>Inicia sesión con el mismo usuario y contraseña que registraste. Esa contraseña permite descifrar las claves guardadas en la base de datos de XAMPP.</p>
            <p id="registration-success" class="success-notice hidden" role="status">Cuenta registrada correctamente. Inicia sesión con el usuario y la contraseña que acabas de crear.</p>
            <form id="auth-form" data-mode="login">
                <label for="username">Nombre de usuario</label>
                <input id="username" type="text" autocomplete="username" minlength="3" maxlength="80" required autofocus>
                <label for="master-password">Contraseña de acceso</label>
                <input id="master-password" type="password" autocomplete="current-password" required>
                <button class="button button-primary button-wide auth-submit" type="submit">Desbloquear bóveda</button>
            </form>
            <p class="auth-link">¿Eres nuevo? <a href="registro.php">Ir al registro</a></p>
        </section>
        <footer>Gestor local · MySQL de XAMPP · Claves cifradas con AES-256-GCM</footer>
    </main>
    <script src="../app.js" defer></script>
</body>
</html>
