<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gestor de contraseñas</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body class="loading-page">
    <main class="loading">
        <span class="brand-icon" aria-hidden="true">◆</span>
        <p>Preparando tu bóveda...</p>
        <noscript>Este gestor necesita JavaScript habilitado para cargar tus credenciales.</noscript>
    </main>
    <section id="notice" class="notice hidden" role="alert"></section>
    <script src="app.js" defer></script>
</body>
</html>
