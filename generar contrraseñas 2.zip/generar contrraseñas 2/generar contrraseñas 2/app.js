let csrfToken = '';

const currentPage = window.location.pathname.split('/').pop() || 'index.php';
const isViewPage = window.location.pathname.includes('/views/');
const apiPath = isViewPage ? '../api.php' : 'api.php';
const appBasePath = isViewPage ? window.location.pathname.replace(/views\/[^/]+$/, '') : window.location.pathname.replace(/[^/]*$/, '');
const notice = document.getElementById('notice');

function showError(message) {
    if (!notice) {
        window.alert(message);
        return;
    }
    notice.textContent = message;
    notice.classList.remove('hidden');
}

async function request(action, options = {}) {
    const headers = { Accept: 'application/json' };
    if (options.body !== undefined) {
        headers['Content-Type'] = 'application/json';
    }
    if (csrfToken && ['POST', 'DELETE'].includes(options.method || 'GET')) {
        headers['X-CSRF-Token'] = csrfToken;
    }
    const response = await fetch(`${apiPath}?action=${encodeURIComponent(action)}`, {
        ...options,
        headers: { ...headers, ...options.headers },
        credentials: 'same-origin',
    });
    let result;
    try {
        result = await response.json();
    } catch {
        throw new Error('El servidor devolvió una respuesta inválida.');
    }
    if (!response.ok) {
        throw new Error(result.error || 'No se pudo completar la operación.');
    }
    return result;
}

function pageFor(status) {
    if (!status.configured) return 'registro.php';
    if (!status.unlocked) return 'login.php';
    return 'gestor.php';
}

function moveTo(page) {
    const target = `${appBasePath}views/${page}`;
    if (currentPage !== page || !isViewPage) {
        window.location.replace(target);
    }
}

function secureRandomIndex(maximum) {
    const range = 256 - (256 % maximum);
    const value = new Uint8Array(1);
    do {
        crypto.getRandomValues(value);
    } while (value[0] >= range);
    return value[0] % maximum;
}

function generatePassword(length = 20) {
    const groups = [
        'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        'abcdefghijklmnopqrstuvwxyz',
        '0123456789',
        '!@#$%^&*()-_=+[]{}?',
    ];
    const allCharacters = groups.join('');
    const characters = groups.map((group) => group[secureRandomIndex(group.length)]);
    while (characters.length < length) {
        characters.push(allCharacters[secureRandomIndex(allCharacters.length)]);
    }
    for (let index = characters.length - 1; index > 0; index -= 1) {
        const swapIndex = secureRandomIndex(index + 1);
        [characters[index], characters[swapIndex]] = [characters[swapIndex], characters[index]];
    }
    return characters.join('');
}

function addText(parent, tagName, className, text) {
    const element = document.createElement(tagName);
    if (className) element.className = className;
    element.textContent = text;
    parent.append(element);
    return element;
}

function renderHistory(entries) {
    const list = document.getElementById('history-list');
    const empty = document.getElementById('history-empty');
    const count = document.getElementById('history-count');
    if (!list || !empty || !count) return;
    list.replaceChildren();
    count.textContent = `(${entries.length})`;
    empty.classList.toggle('hidden', entries.length !== 0);
    entries.forEach((entry) => {
        const card = document.createElement('article');
        card.className = 'panel credential-card';
        const main = document.createElement('div');
        main.className = 'credential-main';
        const title = entry.type === 'credential' ? entry.service : entry.category;
        addText(main, 'div', 'credential-name', title);
        addText(main, 'span', 'category-badge', entry.type === 'credential' ? `Credencial · ${entry.category}` : 'Generada');
        const details = entry.type === 'credential'
            ? `${entry.username || 'Sin usuario'} · Guardada ${entry.createdAt}`
            : `Categoría: ${entry.category} · Generada ${entry.createdAt}`;
        addText(main, 'p', 'credential-meta', details);
        if (entry.type === 'credential' && entry.url) {
            try {
                const parsedUrl = new URL(entry.url);
                if (parsedUrl.protocol === 'http:' || parsedUrl.protocol === 'https:') {
                    const link = addText(main, 'a', 'history-link', entry.url);
                    link.href = parsedUrl.href;
                    link.target = '_blank';
                    link.rel = 'noopener noreferrer';
                }
            } catch {
                // Invalid or non-web URLs are kept as non-clickable text.
            }
        }
        const password = document.createElement('input');
        password.className = 'credential-password';
        password.type = 'text';
        password.value = entry.encryptedValue;
        password.readOnly = true;
        password.setAttribute('aria-label', 'Contraseña guardada');
        main.append(password);
        const actions = document.createElement('div');
        actions.className = 'credential-actions';
        const reveal = addText(actions, 'button', 'button button-secondary', 'Desencriptar');
        reveal.type = 'button';
        reveal.addEventListener('click', async () => {
            if (reveal.textContent === 'Encriptar') {
                password.value = entry.encryptedValue;
                reveal.textContent = 'Desencriptar';
                return;
            }
            reveal.disabled = true;
            try {
                const result = await request('reveal_history', {
                    method: 'POST',
                    body: JSON.stringify({ id: entry.id }),
                });
                password.value = result.password;
                password.type = 'text';
                reveal.textContent = 'Encriptar';
            } catch (error) {
                showError(error.message);
            } finally {
                reveal.disabled = false;
            }
        });
        const copy = addText(actions, 'button', 'button button-secondary', 'Copiar');
        copy.type = 'button';
        copy.addEventListener('click', async () => {
            try {
                const result = await request('reveal_history', {
                    method: 'POST',
                    body: JSON.stringify({ id: entry.id }),
                });
                await navigator.clipboard.writeText(result.password);
                copy.textContent = 'Copiada';
                window.setTimeout(() => { copy.textContent = 'Copiar'; }, 1500);
            } catch {
                showError('No se pudo copiar. Comprueba que el navegador permita acceso al portapapeles.');
            }
        });
        const remove = addText(actions, 'button', 'button delete-button', 'Eliminar');
        remove.type = 'button';
        remove.addEventListener('click', async () => {
            const message = entry.type === 'credential'
                ? '¿Eliminar esta credencial guardada y su entrada del historial?'
                : '¿Eliminar esta contraseña generada del historial?';
            if (!window.confirm(message)) return;
            try {
                await request('delete_history', { method: 'POST', body: JSON.stringify({ id: entry.id }) });
                await loadHistory();
            } catch (error) {
                showError(error.message);
            }
        });
        card.append(main, actions);
        list.append(card);
    });
}

async function loadHistory() {
    const result = await request('history');
    renderHistory(result.history);
}

async function initialize() {
    let status;
    try {
        status = await request('status');
    } catch (error) {
        showError(error.message);
        return;
    }
    csrfToken = status.csrf;
    const expectedPage = pageFor(status);
    if (currentPage === 'index.php' ||
        (currentPage === 'gestor.php' && expectedPage !== 'gestor.php') ||
        (currentPage === 'login.php' && !status.configured)) {
        moveTo(expectedPage);
        return;
    }

    const authForm = document.getElementById('auth-form');
    if (currentPage === 'login.php' && new URLSearchParams(window.location.search).get('registered') === '1') {
        document.getElementById('registration-success')?.classList.remove('hidden');
    }
    if (authForm) {
        authForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            const password = document.getElementById('master-password').value;
            const mode = authForm.dataset.mode;
            const username = document.getElementById('username').value.trim();
            if (mode === 'setup' && password !== document.getElementById('master-confirm').value) {
                showError('Las contraseñas no coinciden.');
                return;
            }
            const submitButton = authForm.querySelector('button[type="submit"]');
            submitButton.disabled = true;
            try {
                const result = await request(mode, {
                    method: 'POST',
                    body: JSON.stringify({ username, masterPassword: password }),
                });
                csrfToken = result.csrf;
                if (mode === 'setup') {
                    window.location.replace(`${appBasePath}views/login.php?registered=1`);
                } else {
                    moveTo('gestor.php');
                }
            } catch (error) {
                showError(error.message);
                submitButton.disabled = false;
            }
        });
    }

    if (currentPage !== 'gestor.php') return;
    const currentUsername = document.getElementById('current-username');
    if (currentUsername && status.username) {
        currentUsername.textContent = status.username;
    }
    const credentialForm = document.getElementById('credential-form');
    const passwordInput = document.getElementById('credential-password');
    const categorySelect = document.getElementById('category');
    const generatedPassword = document.getElementById('generated-password');
    let generatedId = null;
    let generatedEncryptedValue = '';
    document.getElementById('generate-button').addEventListener('click', async () => {
        const lengths = { 'Redes sociales': 14, Banco: 18, Personal: 16, Trabajo: 18, Juegos: 16, Otro: 16 };
        const category = document.getElementById('generator-category').value;
        const password = generatePassword(lengths[category] || 16);
        generatedId = null;
        generatedEncryptedValue = '';
        generatedPassword.value = '';
        try {
            const result = await request('save_history', {
                method: 'POST',
                body: JSON.stringify({ category, password }),
            });
            generatedId = result.id;
            generatedEncryptedValue = result.encryptedValue;
            generatedPassword.value = generatedEncryptedValue;
            await loadHistory();
            notice?.classList.add('hidden');
        } catch (error) {
            generatedPassword.value = '';
            showError(error.message);
        }
    });
    document.getElementById('use-generated-button').addEventListener('click', () => {
        if (!generatedId || !generatedEncryptedValue) {
            showError('Primero genera una contraseña.');
            return;
        }
        passwordInput.value = generatedEncryptedValue;
        passwordInput.dataset.generatedHistoryId = String(generatedId);
        passwordInput.dataset.generatedCiphertext = generatedEncryptedValue;
        categorySelect.value = document.getElementById('generator-category').value;
        passwordInput.type = 'text';
        passwordInput.focus();
    });
    passwordInput.addEventListener('input', () => {
        if (passwordInput.dataset.generatedHistoryId &&
            passwordInput.value !== passwordInput.dataset.generatedCiphertext) {
            delete passwordInput.dataset.generatedHistoryId;
            delete passwordInput.dataset.generatedCiphertext;
        }
    });
    credentialForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const submitButton = credentialForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        const formData = new FormData(credentialForm);
        try {
            await request('create', {
                method: 'POST',
                body: JSON.stringify({
                    service: formData.get('service'),
                    category: formData.get('category'),
                    username: formData.get('username'),
                    url: formData.get('url'),
                    password: formData.get('password'),
                    generatedHistoryId: passwordInput.dataset.generatedHistoryId || null,
                }),
            });
            credentialForm.reset();
            passwordInput.type = 'password';
            delete passwordInput.dataset.generatedHistoryId;
            delete passwordInput.dataset.generatedCiphertext;
            await loadHistory();
        } catch (error) {
            showError(error.message);
        } finally {
            submitButton.disabled = false;
        }
    });

    document.getElementById('logout-button').addEventListener('click', async () => {
        try {
            await request('logout', { method: 'POST', body: JSON.stringify({}) });
            moveTo('login.php');
        } catch (error) {
            showError(error.message);
        }
    });
    try {
        await loadHistory();
    } catch (error) {
        showError(error.message);
    }
}

initialize();
