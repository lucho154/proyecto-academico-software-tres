<?php
declare(strict_types=1);

const DATABASE_NAME = 'gestor_contrasenas';
const PBKDF2_ITERATIONS = 310000;
const CATEGORIES = ['Redes sociales', 'Banco', 'Personal', 'Trabajo', 'Juegos', 'Otro'];

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

$isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
session_set_cookie_params([
    'httponly' => true,
    'secure' => $isHttps,
    'samesite' => 'Strict',
]);
session_start();

function respond(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function requestData(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw === false ? '' : $raw, true);
    if (!is_array($data)) {
        respond(['error' => 'La solicitud no contiene datos JSON válidos.'], 400);
    }
    return $data;
}

function database(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $localConfigPath = __DIR__ . DIRECTORY_SEPARATOR . 'config.local.php';
    $localConfig = is_file($localConfigPath) ? require $localConfigPath : [];
    if (!is_array($localConfig)) {
        throw new RuntimeException('La configuración local de la base de datos no es válida.');
    }

    $host = getenv('DB_HOST') ?: ($localConfig['host'] ?? '127.0.0.1');
    $port = getenv('DB_PORT') ?: ($localConfig['port'] ?? '3306');
    $user = getenv('DB_USER') ?: ($localConfig['username'] ?? 'root');
    $password = getenv('DB_PASSWORD') ?: ($localConfig['password'] ?? '');
    $databaseName = getenv('DB_NAME') ?: ($localConfig['database'] ?? DATABASE_NAME);
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $databaseName)) {
        throw new RuntimeException('El nombre de la base de datos contiene caracteres no permitidos.');
    }
    $server = new PDO(
        "mysql:host={$host};port={$port};charset=utf8mb4",
        $user,
        $password,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]
    );
    $server->exec('CREATE DATABASE IF NOT EXISTS `' . $databaseName . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo = new PDO(
        "mysql:host={$host};port={$port};dbname={$databaseName};charset=utf8mb4",
        $user,
        $password,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]
    );
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS app_settings (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(80) NOT NULL,
            salt CHAR(32) NOT NULL,
            verifier CHAR(64) NOT NULL,
            UNIQUE KEY unique_username (username)
        ) ENGINE=InnoDB'
    );
    $settingsId = $pdo->query("SHOW COLUMNS FROM app_settings LIKE 'id'")->fetch(PDO::FETCH_ASSOC);
    if ($settingsId && stripos((string) $settingsId['Extra'], 'auto_increment') === false) {
        $pdo->exec('ALTER TABLE app_settings MODIFY id INT UNSIGNED NOT NULL AUTO_INCREMENT');
    }
    if (!$pdo->query("SHOW COLUMNS FROM app_settings LIKE 'username'")->fetch()) {
        $pdo->exec("ALTER TABLE app_settings ADD username VARCHAR(80) NOT NULL DEFAULT 'admin' AFTER id");
    }
    if (!$pdo->query("SHOW INDEX FROM app_settings WHERE Key_name = 'unique_username'")->fetch()) {
        $pdo->exec('ALTER TABLE app_settings ADD UNIQUE KEY unique_username (username)');
    }
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS credentials (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NULL,
            service VARCHAR(120) NOT NULL,
            category VARCHAR(40) NOT NULL DEFAULT \'Personal\',
            username VARCHAR(190) NOT NULL DEFAULT \'\',
            url VARCHAR(500) NOT NULL DEFAULT \'\',
            encrypted_password TEXT NOT NULL,
            iv VARCHAR(24) NOT NULL,
            auth_tag VARCHAR(24) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB'
    );
    if (!$pdo->query("SHOW COLUMNS FROM credentials LIKE 'category'")->fetch()) {
        $pdo->exec("ALTER TABLE credentials ADD category VARCHAR(40) NOT NULL DEFAULT 'Personal' AFTER service");
    }
    if (!$pdo->query("SHOW COLUMNS FROM credentials LIKE 'user_id'")->fetch()) {
        $pdo->exec('ALTER TABLE credentials ADD user_id INT UNSIGNED NULL AFTER id');
    }
    if (!$pdo->query("SHOW INDEX FROM credentials WHERE Key_name = 'credentials_user_id'")->fetch()) {
        $pdo->exec('ALTER TABLE credentials ADD INDEX credentials_user_id (user_id)');
    }
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS password_history (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NULL,
            entry_type VARCHAR(20) NOT NULL DEFAULT \'generated\',
            category VARCHAR(40) NOT NULL,
            service VARCHAR(120) NOT NULL DEFAULT \'\',
            username VARCHAR(190) NOT NULL DEFAULT \'\',
            url VARCHAR(500) NOT NULL DEFAULT \'\',
            credential_id BIGINT UNSIGNED NULL,
            encrypted_password TEXT NOT NULL,
            iv VARCHAR(24) NOT NULL,
            auth_tag VARCHAR(24) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX (created_at)
        ) ENGINE=InnoDB'
    );
    $historyColumns = [
        'user_id' => 'INT UNSIGNED NULL AFTER id',
        'entry_type' => "VARCHAR(20) NOT NULL DEFAULT 'generated' AFTER id",
        'service' => "VARCHAR(120) NOT NULL DEFAULT '' AFTER category",
        'username' => "VARCHAR(190) NOT NULL DEFAULT '' AFTER service",
        'url' => "VARCHAR(500) NOT NULL DEFAULT '' AFTER username",
        'credential_id' => 'BIGINT UNSIGNED NULL AFTER url',
    ];
    foreach ($historyColumns as $column => $definition) {
        if (!$pdo->query("SHOW COLUMNS FROM password_history LIKE " . $pdo->quote($column))->fetch()) {
            $pdo->exec("ALTER TABLE password_history ADD {$column} {$definition}");
        }
    }
    if (!$pdo->query("SHOW INDEX FROM password_history WHERE Key_name = 'history_user_id'")->fetch()) {
        $pdo->exec('ALTER TABLE password_history ADD INDEX history_user_id (user_id)');
    }
    $pdo->exec('UPDATE credentials SET user_id = 1 WHERE user_id IS NULL AND EXISTS (SELECT 1 FROM app_settings WHERE id = 1)');
    $pdo->exec('UPDATE password_history SET user_id = 1 WHERE user_id IS NULL AND EXISTS (SELECT 1 FROM app_settings WHERE id = 1)');
    $pdo->exec(
        "INSERT INTO password_history (user_id, entry_type, category, service, username, url, credential_id, encrypted_password, iv, auth_tag, created_at)
         SELECT c.user_id, 'credential', c.category, c.service, c.username, c.url, c.id, c.encrypted_password, c.iv, c.auth_tag, c.created_at
         FROM credentials c
         LEFT JOIN password_history h ON h.credential_id = c.id AND h.user_id = c.user_id
         WHERE h.id IS NULL AND c.user_id IS NOT NULL"
    );
    return $pdo;
}

function setting(): ?array
{
    $statement = database()->query('SELECT id, username, salt, verifier FROM app_settings WHERE id = 1');
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function accountByUsername(string $username): ?array
{
    $statement = database()->prepare('SELECT id, username, salt, verifier FROM app_settings WHERE username = :username');
    $statement->execute(['username' => $username]);
    $account = $statement->fetch(PDO::FETCH_ASSOC);
    return $account ?: null;
}

function deriveKey(string $masterPassword, string $saltHex): string
{
    $salt = hex2bin($saltHex);
    if ($salt === false) {
        throw new RuntimeException('La configuración de cifrado almacenada no es válida.');
    }
    return hash_pbkdf2('sha256', $masterPassword, $salt, PBKDF2_ITERATIONS, 32, true);
}

function requireCsrf(): void
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($token) || !isset($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $token)) {
        respond(['error' => 'La sesión expiró. Recarga la página e inténtalo de nuevo.'], 403);
    }
}

function requireUnlocked(): string
{
    if (!isset($_SESSION['vault_key'])) {
        respond(['error' => 'Desbloquea la bóveda para continuar.'], 401);
    }
    $key = base64_decode($_SESSION['vault_key'], true);
    if ($key === false || strlen($key) !== 32) {
        unset($_SESSION['vault_key']);
        respond(['error' => 'La sesión de la bóveda no es válida. Vuelve a iniciar sesión.'], 401);
    }
    return $key;
}

function requireUserId(): int
{
    if (!isset($_SESSION['user_id'])) {
        respond(['error' => 'Inicia sesión para acceder a tu bóveda.'], 401);
    }
    return (int) $_SESSION['user_id'];
}

try {
    $action = $_GET['action'] ?? '';
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $csrfActions = ['setup', 'login', 'logout', 'create', 'delete', 'save_history', 'reveal_history', 'delete_history'];
    if (in_array($action, $csrfActions, true)) {
        requireCsrf();
    }

    switch ($action) {
        case 'status':
            database();
            $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
            respond([
                'configured' => setting() !== null,
                'unlocked' => isset($_SESSION['vault_key']) && isset($_SESSION['user_id']),
                'username' => $_SESSION['username'] ?? null,
                'csrf' => $_SESSION['csrf'],
            ]);

        case 'setup':
            if ($method !== 'POST') {
                respond(['error' => 'Método no permitido.'], 405);
            }
            $data = requestData();
            $username = trim(is_string($data['username'] ?? null) ? $data['username'] : '');
            $masterPassword = $data['masterPassword'] ?? '';
            if (!preg_match('/^[\p{L}\p{N}_.@-]{3,80}$/u', $username)) {
                respond(['error' => 'El usuario debe tener entre 3 y 80 caracteres: letras, números, punto, guion, guion bajo o @.'], 422);
            }
            if (!is_string($masterPassword) || strlen($masterPassword) < 12 || strlen($masterPassword) > 1024) {
                respond(['error' => 'La contraseña de acceso debe tener entre 12 y 1024 caracteres.'], 422);
            }
            $salt = random_bytes(16);
            $saltHex = bin2hex($salt);
            $key = hash_pbkdf2('sha256', $masterPassword, $salt, PBKDF2_ITERATIONS, 32, true);
            $verifier = hash_hmac('sha256', 'gestor-contrasenas-verifier-v1', $key);
            $pdo = database();
            $statement = $pdo->prepare('INSERT INTO app_settings (username, salt, verifier) VALUES (:username, :salt, :verifier)');
            try {
                $statement->execute(['username' => $username, 'salt' => $saltHex, 'verifier' => $verifier]);
            } catch (PDOException $error) {
                if ($error->getCode() === '23000') {
                    respond(['error' => 'Ese nombre de usuario ya está registrado. Elige otro o inicia sesión.'], 409);
                }
                throw $error;
            }
            $userId = (int) $pdo->lastInsertId();
            if ($userId === 1) {
                $pdo->prepare('UPDATE credentials SET user_id = :user_id WHERE user_id IS NULL')->execute(['user_id' => $userId]);
                $pdo->prepare('UPDATE password_history SET user_id = :user_id WHERE user_id IS NULL')->execute(['user_id' => $userId]);
                $pdo->prepare(
                    "INSERT INTO password_history (user_id, entry_type, category, service, username, url, credential_id, encrypted_password, iv, auth_tag, created_at)
                     SELECT c.user_id, 'credential', c.category, c.service, c.username, c.url, c.id, c.encrypted_password, c.iv, c.auth_tag, c.created_at
                     FROM credentials c LEFT JOIN password_history h ON h.credential_id = c.id
                     WHERE c.user_id = :user_id AND h.id IS NULL"
                )->execute(['user_id' => $userId]);
            }
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            respond(['ok' => true, 'csrf' => $_SESSION['csrf']]);

        case 'login':
            if ($method !== 'POST') {
                respond(['error' => 'Método no permitido.'], 405);
            }
            $data = requestData();
            $username = trim(is_string($data['username'] ?? null) ? $data['username'] : '');
            $masterPassword = $data['masterPassword'] ?? '';
            $config = accountByUsername($username);
            if ($config === null) {
                respond(['error' => 'Usuario o contraseña incorrectos.'], 401);
            }
            if (!preg_match('/^[\p{L}\p{N}_.@-]{3,80}$/u', $username) ||
                !is_string($masterPassword) || strlen($masterPassword) > 1024) {
                respond(['error' => 'Usuario o contraseña de acceso no válidos.'], 422);
            }
            $key = deriveKey($masterPassword, $config['salt']);
            $verifier = hash_hmac('sha256', 'gestor-contrasenas-verifier-v1', $key);
            if (!hash_equals($config['verifier'], $verifier)) {
                respond(['error' => 'Usuario o contraseña incorrectos.'], 401);
            }
            session_regenerate_id(true);
            $_SESSION['vault_key'] = base64_encode($key);
            $_SESSION['user_id'] = (int) $config['id'];
            $_SESSION['username'] = $username;
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            respond(['ok' => true, 'csrf' => $_SESSION['csrf']]);

        case 'logout':
            if ($method !== 'POST') {
                respond(['error' => 'Método no permitido.'], 405);
            }
            $_SESSION = [];
            session_destroy();
            session_start();
            session_regenerate_id(true);
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            respond(['ok' => true, 'csrf' => $_SESSION['csrf']]);

        case 'list':
            if ($method !== 'GET') {
                respond(['error' => 'Método no permitido.'], 405);
            }
            $key = requireUnlocked();
            $userId = requireUserId();
            $statement = database()->prepare('SELECT id, service, category, username, url, encrypted_password, iv, auth_tag, created_at FROM credentials WHERE user_id = :user_id ORDER BY service ASC, id DESC');
            $statement->execute(['user_id' => $userId]);
            $items = [];
            foreach ($statement->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $iv = base64_decode($row['iv'], true);
                $tag = base64_decode($row['auth_tag'], true);
                $encrypted = base64_decode($row['encrypted_password'], true);
                if ($iv === false || $tag === false || $encrypted === false) {
                    throw new RuntimeException('Una credencial almacenada tiene un formato cifrado inválido.');
                }
                $plain = openssl_decrypt($encrypted, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
                if ($plain === false) {
                    throw new RuntimeException('No se pudo descifrar una credencial. La bóveda podría estar dañada.');
                }
                $items[] = [
                    'id' => (int) $row['id'],
                    'service' => $row['service'],
                    'category' => $row['category'],
                    'username' => $row['username'],
                    'url' => $row['url'],
                    'password' => $plain,
                    'createdAt' => $row['created_at'],
                ];
            }
            respond(['credentials' => $items]);

        case 'create':
            if ($method !== 'POST') {
                respond(['error' => 'Método no permitido.'], 405);
            }
            $key = requireUnlocked();
            $userId = requireUserId();
            $data = requestData();
            $service = trim(is_string($data['service'] ?? null) ? $data['service'] : '');
            $category = $data['category'] ?? '';
            $username = trim(is_string($data['username'] ?? null) ? $data['username'] : '');
            $url = trim(is_string($data['url'] ?? null) ? $data['url'] : '');
            $plain = $data['password'] ?? null;
            $generatedHistoryId = null;
            if (isset($data['generatedHistoryId']) && $data['generatedHistoryId'] !== '') {
                $generatedHistoryId = filter_var(
                    $data['generatedHistoryId'],
                    FILTER_VALIDATE_INT,
                    ['options' => ['min_range' => 1]]
                );
                if ($generatedHistoryId === false) {
                    respond(['error' => 'La contraseña generada seleccionada no es válida.'], 422);
                }
            }
            if ($service === '' || strlen($service) > 120 || !is_string($category) || !in_array($category, CATEGORIES, true) ||
                strlen($username) > 190 || strlen($url) > 500 ||
                !is_string($plain) || $plain === '' || strlen($plain) > 4096) {
                respond(['error' => 'Revisa los campos: el servicio y la contraseña son obligatorios y no deben exceder su longitud máxima.'], 422);
            }
            if ($generatedHistoryId !== null) {
                $generatedStatement = database()->prepare(
                    'SELECT encrypted_password, iv, auth_tag FROM password_history
                     WHERE id = :id AND user_id = :user_id AND entry_type = \'generated\''
                );
                $generatedStatement->execute(['id' => $generatedHistoryId, 'user_id' => $userId]);
                $generatedEntry = $generatedStatement->fetch(PDO::FETCH_ASSOC);
                if (!$generatedEntry) {
                    respond(['error' => 'No se encontró la contraseña generada seleccionada.'], 404);
                }
                $generatedIv = base64_decode($generatedEntry['iv'], true);
                $generatedTag = base64_decode($generatedEntry['auth_tag'], true);
                $generatedEncrypted = base64_decode($generatedEntry['encrypted_password'], true);
                if ($generatedIv === false || $generatedTag === false || $generatedEncrypted === false) {
                    throw new RuntimeException('La contraseña generada tiene un formato cifrado inválido.');
                }
                $generatedCiphertext = rtrim(
                    strtr(base64_encode($generatedIv . $generatedTag . $generatedEncrypted), '+/', '-_'),
                    '='
                );
                if (!hash_equals($generatedCiphertext, $plain)) {
                    respond(['error' => 'La contraseña generada cambió. Vuelve a seleccionarla desde el generador.'], 422);
                }
                $storedCiphertext = $generatedCiphertext;
                $storedEncrypted = $generatedEntry['encrypted_password'];
                $storedIv = $generatedEntry['iv'];
                $storedTag = $generatedEntry['auth_tag'];
            } else {
                $iv = random_bytes(12);
                $tag = '';
                $encrypted = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
                if ($encrypted === false) {
                    throw new RuntimeException('No se pudo cifrar la contraseña.');
                }
                $storedCiphertext = rtrim(
                    strtr(base64_encode($iv . $tag . $encrypted), '+/', '-_'),
                    '='
                );
                $storedEncrypted = base64_encode($encrypted);
                $storedIv = base64_encode($iv);
                $storedTag = base64_encode($tag);
            }
            $pdo = database();
            $pdo->beginTransaction();
            try {
                $statement = $pdo->prepare(
                'INSERT INTO credentials (user_id, service, category, username, url, encrypted_password, iv, auth_tag)
                 VALUES (:user_id, :service, :category, :username, :url, :encrypted, :iv, :tag)'
                );
                $statement->execute([
                'user_id' => $userId,
                    'service' => $service,
                    'category' => $category,
                    'username' => $username,
                    'url' => $url,
                    'encrypted' => $storedEncrypted,
                    'iv' => $storedIv,
                    'tag' => $storedTag,
                ]);
                $credentialId = $pdo->lastInsertId();
                $historyStatement = $pdo->prepare(
                    'INSERT INTO password_history (user_id, entry_type, category, service, username, url, credential_id, encrypted_password, iv, auth_tag)
                     VALUES (:user_id, \'credential\', :category, :service, :username, :url, :credential_id, :encrypted, :iv, :tag)'
                );
                $historyStatement->execute([
                    'user_id' => $userId,
                    'category' => $category,
                    'service' => $service,
                    'username' => $username,
                    'url' => $url,
                    'credential_id' => $credentialId,
                    'encrypted' => $storedEncrypted,
                    'iv' => $storedIv,
                    'tag' => $storedTag,
                ]);
                $pdo->commit();
            } catch (Throwable $error) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $error;
            }
            respond([
                'id' => (int) $credentialId,
                'encryptedValue' => $storedCiphertext,
            ]);

        case 'save_history':
            if ($method !== 'POST') {
                respond(['error' => 'Método no permitido.'], 405);
            }
            $key = requireUnlocked();
            $userId = requireUserId();
            $data = requestData();
            $category = $data['category'] ?? '';
            $plain = $data['password'] ?? null;
            if (!is_string($category) || !in_array($category, CATEGORIES, true) ||
                !is_string($plain) || $plain === '' || strlen($plain) > 4096) {
                respond(['error' => 'La categoría o la contraseña generada no son válidas.'], 422);
            }
            $iv = random_bytes(12);
            $tag = '';
            $encrypted = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
            if ($encrypted === false) {
                throw new RuntimeException('No se pudo cifrar la contraseña del historial.');
            }
            $pdo = database();
            $statement = $pdo->prepare(
                'INSERT INTO password_history (user_id, entry_type, category, encrypted_password, iv, auth_tag)
                 VALUES (:user_id, \'generated\', :category, :encrypted, :iv, :tag)'
            );
            $statement->execute([
                'user_id' => $userId,
                'category' => $category,
                'encrypted' => base64_encode($encrypted),
                'iv' => base64_encode($iv),
                'tag' => base64_encode($tag),
            ]);
            respond([
                'id' => (int) $pdo->lastInsertId(),
                'encryptedValue' => rtrim(strtr(base64_encode($iv . $tag . $encrypted), '+/', '-_'), '='),
            ]);

        case 'history':
            if ($method !== 'GET') {
                respond(['error' => 'Método no permitido.'], 405);
            }
            requireUnlocked();
            $userId = requireUserId();
            $statement = database()->prepare('SELECT id, entry_type, category, service, username, url, credential_id, encrypted_password, iv, auth_tag, created_at FROM password_history WHERE user_id = :user_id ORDER BY id DESC LIMIT 100');
            $statement->execute(['user_id' => $userId]);
            $items = [];
            foreach ($statement->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $iv = base64_decode($row['iv'], true);
                $tag = base64_decode($row['auth_tag'], true);
                $encrypted = base64_decode($row['encrypted_password'], true);
                if ($iv === false || $tag === false || $encrypted === false) {
                    throw new RuntimeException('Una entrada del historial tiene un formato cifrado inválido.');
                }
                $items[] = [
                    'id' => (int) $row['id'],
                    'type' => $row['entry_type'],
                    'category' => $row['category'],
                    'service' => $row['service'],
                    'username' => $row['username'],
                    'url' => $row['url'],
                    'credentialId' => $row['credential_id'] === null ? null : (int) $row['credential_id'],
                    'encryptedValue' => rtrim(strtr(base64_encode($iv . $tag . $encrypted), '+/', '-_'), '='),
                    'createdAt' => $row['created_at'],
                ];
            }
            respond(['history' => $items]);

        case 'reveal_history':
            if ($method !== 'POST') {
                respond(['error' => 'Método no permitido.'], 405);
            }
            $key = requireUnlocked();
            $userId = requireUserId();
            $data = requestData();
            $id = filter_var($data['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if ($id === false) {
                respond(['error' => 'Identificador del historial no válido.'], 422);
            }
            $statement = database()->prepare(
                'SELECT encrypted_password, iv, auth_tag FROM password_history WHERE id = :id AND user_id = :user_id'
            );
            $statement->execute(['id' => $id, 'user_id' => $userId]);
            $row = $statement->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                respond(['error' => 'No se encontró esa contraseña en tu historial.'], 404);
            }
            $iv = base64_decode($row['iv'], true);
            $tag = base64_decode($row['auth_tag'], true);
            $encrypted = base64_decode($row['encrypted_password'], true);
            if ($iv === false || $tag === false || $encrypted === false) {
                throw new RuntimeException('La contraseña almacenada tiene un formato cifrado inválido.');
            }
            $plain = openssl_decrypt($encrypted, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
            if ($plain === false) {
                throw new RuntimeException('No se pudo descifrar la contraseña almacenada.');
            }
            respond(['password' => $plain]);

        case 'delete_history':
            if ($method !== 'POST') {
                respond(['error' => 'Método no permitido.'], 405);
            }
            requireUnlocked();
            $userId = requireUserId();
            $data = requestData();
            $id = filter_var($data['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if ($id === false) {
                respond(['error' => 'Identificador del historial no válido.'], 422);
            }
            $pdo = database();
            $pdo->beginTransaction();
            $lookup = $pdo->prepare('SELECT entry_type, credential_id FROM password_history WHERE id = :id AND user_id = :user_id FOR UPDATE');
            $lookup->execute(['id' => $id, 'user_id' => $userId]);
            $entry = $lookup->fetch(PDO::FETCH_ASSOC);
            if (!$entry) {
                $pdo->rollBack();
                respond(['error' => 'No se encontró esa entrada del historial.'], 404);
            }
            $statement = $pdo->prepare('DELETE FROM password_history WHERE id = :id AND user_id = :user_id');
            $statement->execute(['id' => $id, 'user_id' => $userId]);
            if ($entry['entry_type'] === 'credential' && $entry['credential_id'] !== null) {
                $deleteCredential = $pdo->prepare('DELETE FROM credentials WHERE id = :id AND user_id = :user_id');
                $deleteCredential->execute(['id' => $entry['credential_id'], 'user_id' => $userId]);
            }
            $pdo->commit();
            respond(['ok' => true]);

        case 'delete':
            if ($method !== 'POST') {
                respond(['error' => 'Método no permitido.'], 405);
            }
            requireUnlocked();
            $userId = requireUserId();
            $data = requestData();
            $id = filter_var($data['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if ($id === false) {
                respond(['error' => 'Identificador de credencial no válido.'], 422);
            }
            $pdo = database();
            $history = $pdo->prepare('DELETE FROM password_history WHERE credential_id = :id AND user_id = :user_id');
            $history->execute(['id' => $id, 'user_id' => $userId]);
            $statement = $pdo->prepare('DELETE FROM credentials WHERE id = :id AND user_id = :user_id');
            $statement->execute(['id' => $id, 'user_id' => $userId]);
            if ($statement->rowCount() === 0) {
                respond(['error' => 'No se encontró esa credencial.'], 404);
            }
            respond(['ok' => true]);

        default:
            respond(['error' => 'Acción no válida.'], 404);
    }
} catch (PDOException $error) {
    error_log('Gestor de contrasenas - MySQL: ' . $error->getMessage());
    respond(['error' => 'No se pudo conectar a MySQL. Revisa las credenciales de config.local.php y que el usuario tenga permiso para crear la base de datos y sus tablas.'], 500);
} catch (Throwable $error) {
    error_log('Gestor de contrasenas: ' . $error->getMessage());
    respond(['error' => 'No se pudo completar la operación. Verifica que MySQL esté activo y que PHP tenga PDO MySQL y OpenSSL habilitados.'], 500);
}
