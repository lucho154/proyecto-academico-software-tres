# Gestor de contraseñas

Aplicación local para XAMPP con vistas PHP de registro inicial, inicio de sesión y bóveda. Crea automáticamente la base de datos `gestor_contrasenas` y sus tablas al abrir la aplicación.

## Instalar en XAMPP

1. Copia esta carpeta dentro de `C:\xampp\htdocs\` y ponle el nombre `gestor-contrasenas`.
2. Si tu usuario MySQL tiene contraseña, copia `config.local.example.php` como `config.local.php` y configura allí la contraseña de MySQL que usas en phpMyAdmin.
3. Inicia **Apache** y **MySQL** desde el panel de XAMPP.
4. Abre `http://localhost/gestor-contrasenas/`.
5. Registra tu usuario y contraseña de acceso. Utilizarás esos mismos datos para iniciar sesión.

Por defecto se conecta a MySQL en `127.0.0.1:3306` con el usuario `root` sin contraseña. Si configuraste una contraseña para MySQL en XAMPP, usa el archivo de configuración local indicado arriba; ese archivo está excluido de Git y bloqueado desde Apache. También puedes definir `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD` y, opcionalmente, `DB_NAME` como variables de entorno. El usuario de MySQL necesita permiso para crear la base y las tablas.

El registro permite crear varias cuentas. Al registrarte, la aplicación confirma la creación y te envía al inicio de sesión. Cada cuenta tiene sus propias credenciales e historial, separados de los demás usuarios. La contraseña de acceso se utiliza para cifrar y descifrar las claves almacenadas en MySQL. Al migrar una bóveda anterior, las credenciales existentes se conservan bajo el usuario `admin`. El historial combinado muestra tanto las contraseñas generadas como las credenciales guardadas, con opciones para descifrar, copiar y eliminar. Las contraseñas se cifran con AES-256-GCM usando una clave derivada de la contraseña de acceso; guárdala en un lugar seguro para no perder acceso a tus claves.
