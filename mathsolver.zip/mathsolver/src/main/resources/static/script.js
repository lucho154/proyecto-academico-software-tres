// Esperamos a que el documento HTML esté completamente cargado.
document.addEventListener("DOMContentLoaded", function () {

    // Obtenemos los elementos principales del formulario.
    const selector = document.getElementById("tipo");
    const inputTexto = document.getElementById("ecuacionTextoInput");
    const formulario = document.getElementById("formEcuacion");

    // Identificamos los campos ocultos de entrada para inyectar los coeficientes.
    const campos = {
        a: document.getElementById("a"),
        b: document.getElementById("b"),
        c: document.getElementById("c"),
        a2: document.getElementById("a2"),
        b2: document.getElementById("b2"),
        c2: document.getElementById("c2")
    };

    // Cambia el placeholder de guía según la ecuación elegida.
    function actualizarPlaceholder() {
        const tipo = selector.value;
        
        // Limpiamos los campos obligatorios nativos de los ocultos
        Object.values(campos).forEach(campo => { campo.required = false; });

        if (tipo === "LINEAL") {
            inputTexto.placeholder = "Ejemplo: 3x + 6 = 0 o 2x - 4 = 0";
        } else if (tipo === "CUADRATICA") {
            inputTexto.placeholder = "Ejemplo: 2x^2 + 4x - 6 = 0 u o x^2 - 9 = 0";
        } else if (tipo === "POLINOMICA") {
            inputTexto.placeholder = "Ejemplo: 1x^3 - 6x^2 + 11x - 6 = 0";
        } else if (tipo === "SISTEMA") {
            inputTexto.placeholder = "Ejemplo: 2x+3y=5, 4x-1y=1 (Separa las dos ecuaciones con una coma)";
        } else {
            inputTexto.placeholder = "Selecciona un tipo de ecuación arriba...";
        }
    }

    // Función auxiliar para extraer el valor numérico de un término (ej: "-x" -> -1, "" -> 1, "3" -> 3)
    function extraerCoeficiente(str) {
        if (str === undefined || str === null || str === "") return 0.0;
        if (str === "+" || str === "") return 1.0;
        if (str === "-") return -1.0;
        return parseFloat(str);
    }

    // Interceptamos el envío para procesar matemáticamente la cadena de texto
    formulario.addEventListener("submit", function (e) {
        const tipoEcuacion = selector.value;
        let texto = inputTexto.value.replace(/\s+/g, "").toLowerCase(); // Quitar espacios y pasar a minúsculas
        
        // Guardamos el texto original en el DTO
        document.getElementById("ecuacionTexto").value = inputTexto.value;

        // Resetear todos los campos ocultos a 0 antes de rellenar
        Object.values(campos).forEach(campo => { campo.value = "0"; });

        // --- 1. PROCESAMIENTO ECUACIÓN LINEAL (Ax + B = 0) ---
        if (tipoEcuacion === "LINEAL") {
            if (texto.endsWith("=0")) { texto = texto.slice(0, -2); }

            const regexLineal = /^([+-]?\d*(?:\.\d+)?)x([+-]\d*(?:\.\d+)?)$/;
            const match = texto.match(regexLineal);

            if (match) {
                campos.a.value = extraerCoeficiente(match[1]);
                campos.b.value = parseFloat(match[2]);
            } else {
                e.preventDefault();
                alert("Formato lineal incorrecto. Usa el formato estándar: Ax + B = 0 (Ej: 3x + 6 = 0)");
            }
        }
        
        // --- 2. PROCESAMIENTO ECUACIÓN CUADRÁTICA (Ax^2 + Bx + C = 0) ---
        else if (tipoEcuacion === "CUADRATICA") {
            if (texto.endsWith("=0")) { texto = texto.slice(0, -2); }

            // Soporta Ax^2+Bx+C completa o Ax^2+C incompleta
            const regexCuadratica = /^([+-]?\d*(?:\.\d+)?)x\^2(?:([+-]\d*(?:\.\d+)?)x)?([+-]\d*(?:\.\d+)?)$/;
            const match = texto.match(regexCuadratica);

            if (match) {
                campos.a.value = extraerCoeficiente(match[1]);
                campos.b.value = match[2] ? extraerCoeficiente(match[2]) : 0.0;
                campos.c.value = parseFloat(match[3]);
            } else {
                e.preventDefault();
                alert("Formato cuadrático incorrecto. Usa el formato estándar: Ax^2 + Bx + C = 0 (Ej: 2x^2 + 4x - 6 = 0)");
            }
        }

// --- 3. PROCESAMIENTO ECUACIÓN POLINÓMICA (Soporta Grados 3, 2 y 1 de forma libre) ---
else if (tipoEcuacion === "POLINOMICA") {
    if (texto.endsWith("=0")) { texto = texto.slice(0, -2); }

    // Expresión regular robusta que captura Ax^3 + Bx^2 + Cx + D
    const regexCubica = /^([+-]?\d*(?:\.\d+)?)x\^3([+-]\d*(?:\.\d+)?)x\^2([+-]\d*(?:\.\d+)?)x([+-]\d*(?:\.\d+)?)$/;
    const match = texto.match(regexCubica);

    if (match) {
        // Mapeo ordenado hacia el DTO: a=x³, b=x², c=x, c2=Término Independiente
        campos.a.value = extraerCoeficiente(match[1]); // Coeficiente de x³
        campos.b.value = extraerCoeficiente(match[2]); // Coeficiente de x²
        campos.c.value = extraerCoeficiente(match[3]); // Coeficiente de x
        campos.c2.value = parseFloat(match[4]);         // Número suelto
    } else {
        e.preventDefault();
        alert("Formato polinómico incorrecto. Introduce la ecuación completa (Ejemplo: 1x^3 - 6x^2 + 11x - 6 = 0)");
    }
}

        // --- 4. PROCESAMIENTO SISTEMA DE ECUACIONES 2X2 ---
        // Ecuación 1: Ax + By = C  |  Ecuación 2: Dx + Ey = F
        else if (tipoEcuacion === "SISTEMA") {
            const ecuaciones = texto.split(",");
            if (ecuaciones.length !== 2) {
                e.preventDefault();
                alert("Por favor introduce las dos ecuaciones separadas por una línea o coma (Ej: 2x+3y=5, 4x-1y=1)");
                return;
            }

            const regexEc1 = /^([+-]?\d*(?:\.\d+)?)x([+-]\d*(?:\.\d+)?)y=([+-]?\d*(?:\.\d+)?)$/;
            const regexEc2 = /^([+-]?\d*(?:\.\d+)?)x([+-]\d*(?:\.\d+)?)y=([+-]?\d*(?:\.\d+)?)$/;

            const match1 = ecuaciones[0].match(regexEc1);
            const match2 = ecuaciones[1].match(regexEc2);

            if (match1 && match2) {
                // Primera ecuación -> a, b, c
                campos.a.value = extraerCoeficiente(match1[1]);
                campos.b.value = extraerCoeficiente(match1[2]);
                campos.c.value = parseFloat(match1[3]);

                // Segunda ecuación -> a2, b2, c2
                campos.a2.value = extraerCoeficiente(match2[1]);
                campos.b2.value = extraerCoeficiente(match2[2]);
                campos.c2.value = parseFloat(match2[3]);
            } else {
                e.preventDefault();
                alert("Formato de sistema incorrecto. Asegúrate de estructurarlo como: Ax+By=C, Dx+Ey=F");
            }
        }
    });

    // Escuchamos los cambios del selector
    selector.addEventListener("change", actualizarPlaceholder);

    // Inicializamos al cargar la vista
    actualizarPlaceholder();
});
