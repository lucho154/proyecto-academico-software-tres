package com.company.mathsolver.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.company.mathsolver.model.EcuacionHistorial;

// JpaRepository proporciona operaciones CRUD automáticamente.
// No necesitamos escribir manualmente las consultas básicas.
@Repository
public interface EcuacionRepository
        extends JpaRepository<EcuacionHistorial, Long> {

}