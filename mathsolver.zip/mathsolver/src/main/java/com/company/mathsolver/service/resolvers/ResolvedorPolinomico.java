package com.company.mathsolver.service.resolvers;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import com.company.mathsolver.dto.EcuacionRequest;
import com.company.mathsolver.enums.TipoEcuacion;
import com.company.mathsolver.model.PasoResolucion;
import com.company.mathsolver.model.ResultadoResolucion;

@Component
public class ResolvedorPolinomico implements ResolvedorEcuacion {

    @Override
    public TipoEcuacion getTipo() {
        return TipoEcuacion.POLINOMICA;
    }

    @Override
    public ResultadoResolucion resolver(EcuacionRequest request) {
        // Capturamos los 4 coeficientes reales enviados desde el script del frontend
        double coefA = request.getA();   // x³
        double coefB = request.getB();   // x²
        double coefC = request.getC();   // x
        double coefD = request.getC2();  // Término independiente

        List<PasoResolucion> pasos = new ArrayList<>();
        List<String> soluciones = new ArrayList<>();

        // =========================================================================
        // CASO CASCO 1: DEGRADACIÓN A GRADO 1 (Ecuación Lineal: Cx + D = 0)
        // =========================================================================
        if (coefA == 0 && coefB == 0) {
            pasos.add(new PasoResolucion(1, "Detectar Grado del Polinomio", 
                "Los coeficientes de x³ y x² son cero. El polinomio se degrada a Grado 1 (Lineal).", 
                coefC + "x + (" + coefD + ") = 0"));
            if (coefC != 0) {
                double x = -coefD / coefC;
                soluciones.add("x = " + String.format("%.4f", x));
                pasos.add(new PasoResolucion(2, "Despejar la incógnita x", "Se traslada el término independiente y se divide entre el coeficiente de x.", "x = " + String.format("%.4f", x)));
                return new ResultadoResolucion("Polinomio Lineal (Grado 1)", coefC + "x + (" + coefD + ") = 0", pasos, soluciones, "Solución lineal exacta calculada.");
            } else {
                return new ResultadoResolucion("Polinomio Inválido", "0 = 0", pasos, soluciones, "Ecuación inconsistente o infinitas soluciones.");
            }
        }

        // =========================================================================
        // CASO CASCO 2: DEGRADACIÓN A GRADO 2 (Ecuación Cuadrática: Bx² + Cx + D = 0)
        // =========================================================================
        if (coefA == 0) {
            pasos.add(new PasoResolucion(1, "Detectar Grado del Polinomio", 
                "El coeficiente de x³ es cero. El polinomio se degrada a Grado 2 (Cuadrático).", 
                coefB + "x² + (" + coefC + ")x + (" + coefD + ") = 0"));
            
            double discriminante = (coefC * coefC) - (4 * coefB * coefD);
            pasos.add(new PasoResolucion(2, "Calcular el discriminante", "Calculamos Δ = b² - 4ac para conocer la naturaleza de las raíces.", "Δ = " + discriminante));

            if (discriminante >= 0) {
                double x1 = (-coefC + Math.sqrt(discriminante)) / (2 * coefB);
                double x2 = (-coefC - Math.sqrt(discriminante)) / (2 * coefB);
                soluciones.add("x1 = " + String.format("%.4f", x1));
                soluciones.add("x2 = " + String.format("%.4f", x2));
                pasos.add(new PasoResolucion(3, "Aplicar Fórmula General", "Aplicamos la fórmula cuadrática analítica para obtener soluciones reales exactas.", "x1 = " + String.format("%.4f", x1) + ", x2 = " + String.format("%.4f", x2)));
            } else {
                double parteReal = -coefC / (2 * coefB);
                double parteImaginaria = Math.sqrt(-discriminante) / (2 * coefB);
                soluciones.add("x1 = " + String.format("%.4f", parteReal) + " + " + String.format("%.4f", parteImaginaria) + "i");
                soluciones.add("x2 = " + String.format("%.4f", parteReal) + " - " + String.format("%.4f", parteImaginaria) + "i");
                pasos.add(new PasoResolucion(3, "Raíces Complejas", "El discriminante es negativo, se obtienen dos raíces complejas conjugadas.", "Raíces pertenecientes al conjunto imaginario."));
            }
            return new ResultadoResolucion("Polinomio Cuadrático (Grado 2)", coefB + "x² + (" + coefC + ")x + (" + coefD + ") = 0", pasos, soluciones, "Soluciones cuadráticas exactas calculadas.");
        }

        // =========================================================================
        // CASO CASCO 3: POLINOMIO CÚBICO COMPLETO (Grado 3)
        // =========================================================================
        double[] coeficientes = { coefA, coefB, coefC, coefD };
        int grado = 3;

        pasos.add(new PasoResolucion(
            1,
            "Identificar el polinomio cúbico",
            "Analizamos el polinomio de grado 3 con los coeficientes ingresados.",
            coefA + "x³ + (" + coefB + ")x² + (" + coefC + ")x + (" + coefD + ") = 0"
        ));

        // Búsqueda de raíces enteras por el método de Horner (Tu algoritmo original)
        for (int raiz = -100; raiz <= 100 && grado > 0; raiz++) {
            while (grado > 0 && Math.abs(evaluar(coeficientes, grado, raiz)) < 1e-8) {
                soluciones.add("x = " + raiz);
                pasos.add(new PasoResolucion(
                    pasos.size() + 2,
                    "Encontrar una raíz entera",
                    "El valor entero " + raiz + " satisface la ecuación (hace que el polinomio sea cero).",
                    "x = " + raiz
                ));

                // División sintética / Regla de Ruffini para reducir el grado
                double[] nuevo = new double[grado];
                nuevo[0] = coeficientes[0];
                for (int i = 1; i < grado; i++) {
                    nuevo[i] = coeficientes[i] + raiz * nuevo[i - 1];
                }
                coeficientes = nuevo;
                grado--;
            }
        }

        // FALLBACK ANALÍTICO: Si se redujo a grado 2 o quedó trancado con decimales irracionales
        if (grado == 2) {
            pasos.add(new PasoResolucion(pasos.size() + 2, "Resolución del residuo cuadrático", 
                "El polinomio restante es de grado 2. Aplicamos la fórmula analítica general para evitar la pérdida de soluciones decimales.", 
                coeficientes[0] + "x² + (" + coeficientes[1] + ")x + (" + coeficientes[2] + ") = 0"));
            
            double a2 = coeficientes[0];
            double b2 = coeficientes[1];
            double c2 = coeficientes[2];
            double disc = (b2 * b2) - (4 * a2 * c2);

            if (disc >= 0) {
                double r1 = (-b2 + Math.sqrt(disc)) / (2 * a2);
                double r2 = (-b2 - Math.sqrt(disc)) / (2 * a2);
                soluciones.add("x = " + String.format("%.4f", r1));
                soluciones.add("x = " + String.format("%.4f", r2));
            } else {
                double pReal = -b2 / (2 * a2);
                double pImag = Math.sqrt(-disc) / (2 * a2);
                soluciones.add("x = " + String.format("%.4f", pReal) + " ± " + String.format("%.4f", pImag) + "i");
            }
            grado = 0; // Marcamos como completamente resuelto
        }

        String mensaje;
        if (soluciones.isEmpty()) {
            mensaje = "No se encontraron raíces enteras en el intervalo [-100, 100]. Pruebe con raíces racionales decimales.";
        } else if (grado > 0) {
            mensaje = "Se encontraron raíces parciales, pero el polinomio remanente requiere aproximación decimal compleja.";
        } else {
            mensaje = "Se hallaron con éxito todas las raíces del polinomio de grado 3.";
        }

        return new ResultadoResolucion(
            "Polinomio cúbico (Grado 3)",
            coefA + "x³ + (" + coefB + ")x² + (" + coefC + ")x + (" + coefD + ") = 0",
            pasos,
            soluciones,
            mensaje
        );
    }

    private double evaluar(double[] coeficientes, int grado, double x) {
        double resultado = coeficientes[0];
        for (int i = 1; i <= grado; i++) {
            resultado = resultado * x + coeficientes[i];
        }
        return resultado;
    }
}
