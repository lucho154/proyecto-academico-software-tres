package com.company.mathsolver.service.resolvers;

import com.company.mathsolver.dto.EcuacionRequest;
import com.company.mathsolver.enums.TipoEcuacion;
import com.company.mathsolver.model.ResultadoResolucion;

// Interface: define el contrato que deberán cumplir
// todos los solucionadores de nuestra aplicación.
public interface ResolvedorEcuacion {

    // Identifica el tipo de ecuación que puede resolver cada clase.
    TipoEcuacion getTipo();

    // Ejecuta la lógica matemática y devuelve el procedimiento.
    ResultadoResolucion resolver(EcuacionRequest request);
}
