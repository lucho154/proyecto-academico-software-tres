package com.company.mathsolver.service.resolvers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.company.mathsolver.dto.EcuacionRequest;
import com.company.mathsolver.enums.TipoEcuacion;
import com.company.mathsolver.exception.EcuacionInvalidaException;
import com.company.mathsolver.model.PasoResolucion;
import com.company.mathsolver.model.ResultadoResolucion;

@Component
public class ResolvedorSistema implements ResolvedorEcuacion {

    @Override
    public TipoEcuacion getTipo() {
        return TipoEcuacion.SISTEMA;
    }

    @Override
    public ResultadoResolucion resolver(EcuacionRequest request) {

        double a = request.getA();
        double b = request.getB();
        double c = request.getC();

        double d = request.getA2();
        double e = request.getB2();
        double f = request.getC2();

        List<PasoResolucion> pasos = new ArrayList<>();
        List<String> soluciones = new ArrayList<>();

        // Calculamos el determinante principal.
        double determinante = a * e - b * d;

        pasos.add(new PasoResolucion(
            1,
            "Calcular el determinante",
            "Aplicamos la regla de los determinantes.",
            "D = (" + a + " × " + e + ") - (" + b + " × " + d
                + ") = " + determinante
        ));

        // Si el determinante es cero, el sistema no tiene
        // una solución única. Se debe analizar por separado.
        if (determinante == 0) {

            throw new EcuacionInvalidaException(
                "El sistema no tiene una solución única. "
                + "Puede ser incompatible o tener infinitas soluciones."
            );
        }

        // Calculamos los determinantes para cada incógnita.
        double dx = c * e - b * f;
        double dy = a * f - c * d;

        pasos.add(new PasoResolucion(
            2,
            "Calcular determinante de X",
            "Sustituimos la primera columna por los términos independientes.",
            "Dx = " + dx
        ));

        pasos.add(new PasoResolucion(
            3,
            "Calcular determinante de Y",
            "Sustituimos la segunda columna por los términos independientes.",
            "Dy = " + dy
        ));

        // Aplicamos la regla de Cramer.
        double x = dx / determinante;
        double y = dy / determinante;

        pasos.add(new PasoResolucion(
            4,
            "Encontrar las incógnitas",
            "Dividimos cada determinante entre el determinante principal.",
            "x = " + x + " ; y = " + y
        ));

        soluciones.add("x = " + x);
        soluciones.add("y = " + y);

        return new ResultadoResolucion(
            "Sistema de ecuaciones",
            "Sistema de dos ecuaciones con dos incógnitas",
            pasos,
            soluciones,
            "Sistema resuelto correctamente."
        );
    }
}