package com.company.mathsolver.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;

// @Configuration indica que esta clase contiene configuraciones
// administradas por el contenedor de Spring.
@Configuration
public class AppConfig {

    // @Bean registra el objeto devuelto en el contenedor de Spring.
    // Clock nos permitirá trabajar con fechas y horas de forma
    // controlada y facilitará las pruebas.
    @Bean
    public Clock clock() {
        return Clock.systemDefaultZone();
    }
}
