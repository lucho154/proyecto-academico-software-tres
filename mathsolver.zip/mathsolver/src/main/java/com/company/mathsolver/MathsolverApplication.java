package com.company.mathsolver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Punto de entrada de nuestra aplicación.
// @SpringBootApplication habilita la configuración automática,
// el escaneo de componentes y la configuración de Spring Boot.
@SpringBootApplication
public class MathsolverApplication {

    public static void main(String[] args) {

        // Iniciamos el contexto de Spring y el servidor web.
        SpringApplication.run(MathsolverApplication.class, args);
    }
}