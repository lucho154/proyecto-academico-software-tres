package com.company.mathsolver.model;

import java.util.List;

// Contiene el resultado general de una operación matemática.
// Separa el procedimiento de la presentación HTML.
public class ResultadoResolucion {

    private String tipo;
    private String ecuacionOriginal;
    private List<PasoResolucion> pasos;
    private List<String> soluciones;
    private String mensaje;

    public ResultadoResolucion(String tipo, String ecuacionOriginal,
            List<PasoResolucion> pasos, List<String> soluciones,
            String mensaje) {

        this.tipo = tipo;
        this.ecuacionOriginal = ecuacionOriginal;
        this.pasos = pasos;
        this.soluciones = soluciones;
        this.mensaje = mensaje;
    }

    public String getTipo() {
        return tipo;
    }

    public String getEcuacionOriginal() {
        return ecuacionOriginal;
    }

    public List<PasoResolucion> getPasos() {
        return pasos;
    }

    public List<String> getSoluciones() {
        return soluciones;
    }

    public String getMensaje() {
        return mensaje;
    }
}