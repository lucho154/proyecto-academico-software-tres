package com.company.mathsolver.exception;

// RuntimeException permite crear excepciones no verificadas.
// La utilizamos cuando una ecuación no cumple las condiciones
// necesarias para ser resuelta.
public class EcuacionInvalidaException extends RuntimeException {

    public EcuacionInvalidaException(String mensaje) {
        super(mensaje);
    }
}