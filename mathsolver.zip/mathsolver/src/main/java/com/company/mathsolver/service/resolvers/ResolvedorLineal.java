package com.company.mathsolver.service.resolvers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.company.mathsolver.dto.EcuacionRequest;
import com.company.mathsolver.enums.TipoEcuacion;
import com.company.mathsolver.exception.EcuacionInvalidaException;
import com.company.mathsolver.model.PasoResolucion;
import com.company.mathsolver.model.ResultadoResolucion;

// @Component registra esta clase como un objeto administrado por Spring.
// Así podremos inyectarla en otros componentes.
@Component
public class ResolvedorLineal implements ResolvedorEcuacion {

    @Override
    public TipoEcuacion getTipo() {
        return TipoEcuacion.LINEAL;
    }

    @Override
    public ResultadoResolucion resolver(EcuacionRequest request) {

        double a = request.getA();
        double b = request.getB();

        // Una ecuación lineal necesita que el coeficiente
        // de x sea diferente de cero.
        if (a == 0) {
            throw new EcuacionInvalidaException(
                "El coeficiente de x no puede ser cero."
            );
        }

        // Lista que almacenará los pasos matemáticos.
        List<PasoResolucion> pasos = new ArrayList<>();

        // Paso 1: ecuación original.
        pasos.add(new PasoResolucion(
            1,
            "Ecuación original",
            "Identificamos los coeficientes de la ecuación.",
            a + "x + (" + b + ") = 0"
        ));

        // Paso 2: trasladar el término independiente.
        pasos.add(new PasoResolucion(
            2,
            "Despejar la incógnita",
            "Pasamos el término independiente al otro lado.",
            a + "x = " + (-b)
        ));

        // Paso 3: dividir ambos lados entre a.
        double resultado = -b / a;

        pasos.add(new PasoResolucion(
            3,
            "Dividir entre el coeficiente",
            "Dividimos ambos lados entre " + a + ".",
            "x = " + resultado
        ));

        // Guardamos la solución como texto para mostrarla.
        List<String> soluciones = new ArrayList<>();
        soluciones.add("x = " + resultado);

        return new ResultadoResolucion(
            "Ecuación lineal",
            a + "x + (" + b + ") = 0",
            pasos,
            soluciones,
            "Ecuación resuelta correctamente."
        );
    }
}