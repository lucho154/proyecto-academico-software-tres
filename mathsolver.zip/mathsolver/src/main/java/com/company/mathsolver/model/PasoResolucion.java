package com.company.mathsolver.model;

// Esta clase representa un paso del procedimiento matemático.
// Cada objeto contendrá información que posteriormente
// mostraremos como una tarjeta en nuestra página HTML.
public class PasoResolucion {

    private int numero;
    private String titulo;
    private String explicacion;
    private String expresion;

    // Constructor para inicializar todos los atributos.
    public PasoResolucion(int numero, String titulo,
                          String explicacion, String expresion) {
        this.numero = numero;
        this.titulo = titulo;
        this.explicacion = explicacion;
        this.expresion = expresion;
    }

    // Getters: permiten consultar los valores de los atributos.
    public int getNumero() {
        return numero;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getExplicacion() {
        return explicacion;
    }

    public String getExpresion() {
        return expresion;
    }
}