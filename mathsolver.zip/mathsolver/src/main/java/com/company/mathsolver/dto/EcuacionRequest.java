package com.company.mathsolver.dto;

// Esta clase recibe los valores introducidos por el usuario.
// No contiene operaciones matemáticas: solamente transporta datos.
public class EcuacionRequest {

    private String tipo;

    // NUEVOS CAMPOS: Para soportar la escritura directa sin perder lo anterior
    private String modoInput;    // Puede ser "coeficientes" o "texto"
    private String ecuacionTexto; // Guarda la ecuación completa, ej: "3x + 6 = 0"

    // Coeficientes para ecuaciones lineales y cuadráticas.
    private double a;
    private double b;
    private double c;

    // Coeficientes adicionales para sistemas de ecuaciones.
    private double a2;
    private double b2;
    private double c2;

    // GETTERS Y SETTERS DE LOS NUEVOS CAMPOS
    public String getModoInput() { return modoInput; }
    public void setModoInput(String modoInput) { this.modoInput = modoInput; }

    public String getEcuacionTexto() { return ecuacionTexto; }
    public void setEcuacionTexto(String ecuacionTexto) { this.ecuacionTexto = ecuacionTexto; }

    // GETTERS Y SETTERS EXISTENTES (No se tocan)
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public double getA() { return a; }
    public void setA(double a) { this.a = a; }

    public double getB() { return b; }
    public void setB(double b) { this.b = b; }

    public double getC() { return c; }
    public void setC(double c) { this.c = c; }

    public double getA2() { return a2; }
    public void setA2(double a2) { this.a2 = a2; }

    public double getB2() { return b2; }
    public void setB2(double b2) { this.b2 = b2; }

    public double getC2() { return c2; }
    public void setC2(double c2) { this.c2 = c2; }
}