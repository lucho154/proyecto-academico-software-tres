package com.company.mathsolver.service.resolvers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.company.mathsolver.dto.EcuacionRequest;
import com.company.mathsolver.enums.TipoEcuacion;
import com.company.mathsolver.exception.EcuacionInvalidaException;
import com.company.mathsolver.model.PasoResolucion;
import com.company.mathsolver.model.ResultadoResolucion;

@Component
public class ResolvedorCuadratico implements ResolvedorEcuacion {

    @Override
    public TipoEcuacion getTipo() {
        return TipoEcuacion.CUADRATICA;
    }

    @Override
    public ResultadoResolucion resolver(EcuacionRequest request) {

        double a = request.getA();
        double b = request.getB();
        double c = request.getC();

        // Validamos que sea realmente una ecuación cuadrática.
        if (a == 0) {
            throw new EcuacionInvalidaException(
                "El coeficiente a debe ser diferente de cero."
            );
        }

        List<PasoResolucion> pasos = new ArrayList<>();
        List<String> soluciones = new ArrayList<>();

        // Paso 1: presentamos la ecuación.
        pasos.add(new PasoResolucion(
            1,
            "Ecuación original",
            "Identificamos los tres coeficientes.",
            a + "x² + (" + b + ")x + (" + c + ") = 0"
        ));

        // Paso 2: calculamos el discriminante.
        double discriminante = b * b - 4 * a * c;

        pasos.add(new PasoResolucion(
            2,
            "Calcular el discriminante",
            "Aplicamos la expresión b² - 4ac.",
            "Δ = " + discriminante
        ));

        // El discriminante determina la naturaleza de las raíces.
        if (discriminante < 0) {

            return new ResultadoResolucion(
                "Ecuación cuadrática",
                a + "x² + " + b + "x + " + c + " = 0",
                pasos,
                soluciones,
                "No existen soluciones reales. Las raíces son complejas."
            );
        }

        // Paso 3: calculamos las dos soluciones.
        double x1 = (-b + Math.sqrt(discriminante)) / (2 * a);
        double x2 = (-b - Math.sqrt(discriminante)) / (2 * a);

        pasos.add(new PasoResolucion(
            3,
            "Aplicar la fórmula general",
            "Sustituimos los coeficientes en la fórmula cuadrática.",
            "x = (-" + b + " ± √" + discriminante + ") / " + (2 * a)
        ));

        pasos.add(new PasoResolucion(
            4,
            "Obtener las raíces",
            "Calculamos las dos posibles soluciones.",
            "x₁ = " + x1 + " ; x₂ = " + x2
        ));

        soluciones.add("x₁ = " + x1);
        soluciones.add("x₂ = " + x2);

        return new ResultadoResolucion(
            "Ecuación cuadrática",
            a + "x² + " + b + "x + " + c + " = 0",
            pasos,
            soluciones,
            "Ecuación resuelta correctamente."
        );
    }
}