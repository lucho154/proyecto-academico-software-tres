//representación de los datos

package com.company.mathsolver.enums;

// Enum: representa los tipos de ecuaciones admitidos.
// Es más seguro utilizar valores definidos que escribir
// cadenas de texto diferentes por toda la aplicación.
public enum TipoEcuacion {
    LINEAL,
    CUADRATICA,
    SISTEMA,
    POLINOMICA
}