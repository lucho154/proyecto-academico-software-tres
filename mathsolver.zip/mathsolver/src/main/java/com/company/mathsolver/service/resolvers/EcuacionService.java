package com.company.mathsolver.service.resolvers;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.company.mathsolver.dto.EcuacionRequest;
import com.company.mathsolver.enums.TipoEcuacion;
import com.company.mathsolver.exception.EcuacionInvalidaException;
import com.company.mathsolver.model.ResultadoResolucion;
import com.company.mathsolver.model.EcuacionHistorial;
import com.company.mathsolver.Repository.EcuacionRepository;
import com.company.mathsolver.service.resolvers.ResolvedorEcuacion;

// @Service identifica esta clase como un servicio de Spring.
// Aquí centralizamos la lógica de negocio de la aplicación.
@Service
public class EcuacionService {

    // Logger: permite registrar información y errores
    // sin utilizar System.out.println().
    private static final Logger logger =
            LoggerFactory.getLogger(EcuacionService.class);

    // Lista de solucionadores disponibles.
    private final List<ResolvedorEcuacion> resolvedores;

    // Repositorio encargado de guardar el historial en MySQL.
    private final EcuacionRepository repository;

    // Clock permite obtener la fecha y hora actual.
    private final Clock clock;

    // Inyección de dependencias por constructor.
    // Spring proporciona automáticamente los objetos necesarios.
    public EcuacionService(
            List<ResolvedorEcuacion> resolvedores,
            EcuacionRepository repository,
            Clock clock) {

        this.resolvedores = resolvedores;
        this.repository = repository;
        this.clock = clock;
    }

    // @Transactional permite ejecutar la operación
    // dentro de una transacción de base de datos.
    @Transactional
    public ResultadoResolucion resolver(EcuacionRequest request) {

        // Validamos que el usuario haya seleccionado un tipo.
        if (request.getTipo() == null || request.getTipo().isBlank()) {

            throw new EcuacionInvalidaException(
                    "Debes seleccionar un tipo de ecuación."
            );
        }

        TipoEcuacion tipo;

        try {

            // Convertimos el texto recibido a un valor del Enum.
            tipo = TipoEcuacion.valueOf(
                    request.getTipo().trim().toUpperCase()
            );

        } catch (IllegalArgumentException exception) {

            logger.warn(
                    "Tipo de ecuación no reconocido: {}",
                    request.getTipo()
            );

            throw new EcuacionInvalidaException(
                    "El tipo de ecuación seleccionado no existe."
            );
        }

        logger.info(
                "Iniciando resolución de ecuación: {}",
                tipo
        );

        // STREAM:
        // Recorremos la lista de solucionadores.
        // FILTER: buscamos el que corresponda al tipo seleccionado.
        // FIND FIRST: obtenemos la primera coincidencia.
        Optional<ResolvedorEcuacion> encontrado = resolvedores.stream()
                .filter(resolvedor -> resolvedor.getTipo() == tipo)
                .findFirst();

        // OPTIONAL:
        // Si no existe un solucionador, lanzamos una excepción.
        ResolvedorEcuacion solucionador = encontrado.orElseThrow(
                () -> new EcuacionInvalidaException(
                        "No existe un solucionador para este tipo de ecuación."
                )
        );

        // Ejecutamos la lógica matemática del solucionador.
        ResultadoResolucion resultado = solucionador.resolver(request);

        // Creamos un objeto para representar el registro histórico.
        EcuacionHistorial historial = new EcuacionHistorial();

        historial.setTipo(resultado.getTipo());

        historial.setEcuacion(
                resultado.getEcuacionOriginal()
        );

        // STREAM + COLLECT:
        // Transformamos la lista de soluciones en una sola cadena.
        // Ejemplo: ["x = 2", "x = 3"] -> "x = 2 | x = 3".
        String solucionesTexto = resultado.getSoluciones().stream()
                .collect(Collectors.joining(" | "));

        historial.setSoluciones(solucionesTexto);

        // Registramos la fecha y hora de la consulta.
        historial.setFecha(LocalDateTime.now(clock));

        // Guardamos el registro utilizando Spring Data JPA.
        repository.save(historial);

        logger.info(
                "Ecuación resuelta y guardada correctamente: {}",
                tipo
        );

        // Devolvemos el resultado al controlador MVC.
        return resultado;
    }
}