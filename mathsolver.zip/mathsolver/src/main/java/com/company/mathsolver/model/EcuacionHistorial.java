package com.company.mathsolver.model;

import java.time.LocalDateTime;

import jakarta.persistence.*;

// @Entity indica que esta clase representa una tabla de MySQL.
@Entity
@Table(name = "ecuaciones_historial")
public class EcuacionHistorial {

    // Identificador único de cada consulta.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Tipo de ecuación resuelta.
    private String tipo;

    // Expresión original introducida por el usuario.
    @Column(length = 500)
    private String ecuacion;

    // Resultado de la operación.
    @Column(length = 2000)
    private String soluciones;

    // Fecha en la que se realizó la consulta.
    private LocalDateTime fecha;

    // Constructor vacío requerido por JPA.
    public EcuacionHistorial() {
    }

    public Long getId() { return id; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getEcuacion() { return ecuacion; }
    public void setEcuacion(String ecuacion) { this.ecuacion = ecuacion; }

    public String getSoluciones() { return soluciones; }
    public void setSoluciones(String soluciones) {
        this.soluciones = soluciones;
    }

    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }
}
