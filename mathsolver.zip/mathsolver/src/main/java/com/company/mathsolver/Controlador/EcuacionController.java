package com.company.mathsolver.Controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.company.mathsolver.dto.EcuacionRequest;
import com.company.mathsolver.service.resolvers.EcuacionService;

// @Controller indica que esta clase administra las solicitudes web
// y devuelve vistas HTML mediante Thymeleaf.
@Controller
public class EcuacionController {

    private final EcuacionService service;

    // Inyección de dependencias por constructor.
    public EcuacionController(EcuacionService service) {
        this.service = service;
    }

    // GET: muestra la página inicial.
    @GetMapping("/")
    public String inicio(Model model) {

        // Creamos un formulario vacío para Thymeleaf.
        model.addAttribute("request", new EcuacionRequest());

        return "index";
    }

    // POST: recibe los datos del formulario.
    @PostMapping("/resolver")
    public String resolver(
            @ModelAttribute("request") EcuacionRequest request,
            Model model) {

        // Enviamos los datos al servicio matemático.
        model.addAttribute("resultado", service.resolver(request));

        return "index";
    }
}