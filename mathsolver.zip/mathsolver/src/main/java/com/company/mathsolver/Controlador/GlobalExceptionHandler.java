package com.company.mathsolver.Controlador;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.company.mathsolver.exception.EcuacionInvalidaException;

// @ControllerAdvice permite centralizar el manejo de errores
// de los diferentes controladores de nuestra aplicación.
@ControllerAdvice
public class GlobalExceptionHandler {

    // @ExceptionHandler identifica qué excepciones atender.
    @ExceptionHandler(EcuacionInvalidaException.class)
    public String manejarEcuacionInvalida(
            EcuacionInvalidaException exception,
            Model model) {

        // Enviamos el mensaje de error a la interfaz.
        model.addAttribute("error", exception.getMessage());

        // Conservamos un formulario vacío para permitir otro intento.
        model.addAttribute("request", new com.company.mathsolver.dto.EcuacionRequest());

        return "index";
    }
}
